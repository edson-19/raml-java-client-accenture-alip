
import org.mule.example.api.AlipnewbusinessClient;
import org.mule.example.exceptions.AlipnewbusinessException;
import org.mule.example.resource.application.id.postSubmit.details.model.DetailsGETQueryParam;
import org.mule.example.resource.application.id.postSubmit.details.model.DetailsGETResponseBody;
import org.mule.example.responses.AlipnewbusinessResponse;

public class ClientPostSubmitExample {
    public static void main(String[] args) {
        try {
            DetailsGETQueryParam queryParameters = new DetailsGETQueryParam("client_secret", "client_id");
			final AlipnewbusinessResponse<DetailsGETResponseBody> result = 
            	AlipnewbusinessClient.create("http://10.6.44.198:8080/relrt12wsgateway/api/ext-portal")
            		.application.id("1268").postSubmit.details.get(queryParameters);
               		
            System.out.println ("TransRefGUID: " + result.getBody().getTXLife().getTXLifeResponse().getTransRefGUID());
            System.out.println ("TransExeDate: " + result.getBody().getTXLife().getTXLifeResponse().getTransExeDate());
            System.out.println ("TransExeTime: " + result.getBody().getTXLife().getTXLifeResponse().getTransExeTime());
            System.out.println ("ResultCode: " + result.getBody().getTXLife().getTXLifeResponse().getTransResult().getResultCode().get$());

        } catch ( AlipnewbusinessException e ) {
            System.err.println("ERROR: " + e.getStatusCode() + " " + e.getReason());
            System.err.println("ERROR: " + e.getResponse().toString());
        }
    }
    
}
