/**
import org.mule.example.api.ClientAPIClient;
import org.mule.example.exceptions.ClientAPIException;
import org.mule.example.resource.users.userId.model.UserIdGETResponseBody;
import org.mule.example.responses.ClientAPIResponse;

import org.mule.example.api.AlipagentClient;
import org.mule.example.exceptions.AlipagentException;
import org.mule.example.resource.agents.id.summary.model.SummaryGETResponseBody;
import org.mule.example.resource.agents.id.summary.model.SummaryGETQueryParam;
import org.mule.example.responses.AlipagentResponse;

import org.mule.example.api.AlipbankingClient;
import org.mule.example.exceptions.AlipbankingException;
import org.mule.example.resource.customers.id.accounts.model.AccountsGETResponseBody;
import org.mule.example.resource.customers.id.accounts.model.AccountsGETQueryParam;
import org.mule.example.responses.AlipbankingResponse;
**/

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.mule.example.api.AlipnewbusinessClient;
import org.mule.example.exceptions.AlipnewbusinessException;
import org.mule.example.resource.agents.id.dashboard.applications.startDate.endDate.model.EndDateGETResponseBody;
import org.mule.example.resource.application.submit.model.*;

import org.mule.example.responses.AlipnewbusinessResponse;

import com.fasterxml.jackson.databind.ObjectMapper;


public class ClientSearchExample {
    public static void main(String[] args) {
        try {
            //final ClientAPIResponse<UserIdGETResponseBody> result = ClientAPIClient.create().users.userId("luis").get();
            //final AlipagentResponse<SummaryGETResponseBody> result = AlipagentClient.create().agents.id("131").
            //	summary.get(new SummaryGETQueryParam("clientSecret", "clientId"));
            //final AlipbankingResponse<AccountsGETResponseBody> result = AlipbankingClient.create().customers.id("1172").
            //	accounts.get(new AccountsGETQueryParam("clientSecret", "clientId"));
            final AlipnewbusinessResponse<EndDateGETResponseBody> result = 
            	AlipnewbusinessClient.create().agents.id("navy01")
            		.dashboard.applications.startDate("20170101").endDate("20181231")
               		.get();

//        	input();
//            final AlipnewbusinessResponse<SubmitPOSTResponseBody> result = 
//                	AlipnewbusinessClient.create("http://10.6.44.198:8080/relrt12wsgateway/api/ext-portal")
//                	.application.submit.post(body());
            
            System.out.println ("TransRefGUID: " + result.getBody().getTXLife().getTXLifeResponse().getTransRefGUID());
            System.out.println ("TransExeDate: " + result.getBody().getTXLife().getTXLifeResponse().getTransExeDate());
            System.out.println ("TransExeTime: " + result.getBody().getTXLife().getTXLifeResponse().getTransExeTime());
            System.out.println ("ResultCode: " + result.getBody().getTXLife().getTXLifeResponse().getTransResult().getResultCode().get$());
            //System.out.println ("BankName: " + result.getBody().getTXLife().getTXLifeResponse().getOLifE().getHolding().get(0).getBanking().getBankName());
        //} catch ( ClientAPIException e ) {
        //} catch ( AlipagentException e ) {
        //} catch ( AlipbankingException e ) {
        } catch ( AlipnewbusinessException e ) {
            System.err.println("ERROR: " + e.getStatusCode() + " " + e.getReason());
            System.err.println("ERROR: " + e.getResponse().toString());
            
        }
    }
    
    public static SubmitPOSTBody body() {
    	SubmitPOSTBody body;
    	String json = input(); //json();
        ObjectMapper mapper = new ObjectMapper();
        try {
        	body = mapper.readValue(json, SubmitPOSTBody.class);
            
        	System.out.println("REQUEST: " + body.toString());
            System.out.println("UserLoginName: " + body.getTXLife().getUserAuthRequest().getUserLoginName());
            System.out.println("TransRefGUID: " + body.getTXLife().getTXLifeRequest().getTransRefGUID());
            System.out.println("DraftDate: " + body.getTXLife().getTXLifeRequest().getOLifE().getHolding().get(0).getPolicy().getOLifEExtension().getDraftDate());
            
    		return body;
        } catch (IOException e) {
            e.printStackTrace();
        }
		return null;
    	
    }
    
    public static String input(){
      String input = null;
      StringBuilder builder = new StringBuilder();
      FileReader fr = null;
      BufferedReader br = null;
      try {
    	fr = new FileReader("src\\test\\java\\nb_submit_req.json");
    	br = new BufferedReader(fr);
    	String sCurrentLine;
		while ((sCurrentLine = br.readLine()) != null) {
			//System.out.println(sCurrentLine);
			builder.append(sCurrentLine);
		}
    	fr.close();
    	br.close();
      } catch (IOException e) {
    	  e.printStackTrace();
      } 
      //System.out.println("input: " + input);
      input = builder.toString();
      return input;
    }
    
}
