
# ApplicationsubmitTXLifeRequestOLifEInvestment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subAccount** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEInvestmentSubAccount&gt;**](ApplicationsubmitTXLifeRequestOLifEInvestmentSubAccount.md) |  |  [optional]



