
import org.mule.example.api.AlipcontractClient;
import org.mule.example.exceptions.AlipcontractException;
import org.mule.example.resource.contracts.id.billing.model.BillingGETResponseBody;
import org.mule.example.responses.AlipcontractResponse;

public class GetContractIdBillingExample {
    public static void main(String[] args) {
        try {
			final AlipcontractResponse<BillingGETResponseBody> result = 
					AlipcontractClient.create("http://10.6.44.198:8080/relrt12wsgateway/api/ext-portal")
            		.contracts.id("07675").billing.get();
			
			System.out.println ("Response: " + result.getBody().toString());   		
            //System.out.println ("TransRefGUID: " + result.getBody().getTXLifeResponse().getTransRefGUID());
            //System.out.println ("TransExeDate: " + result.getBody().getTXLifeResponse().get.getTransExeDate());
            //System.out.println ("TransExeTime: " + result.getBody().getTXLifeResponse().getTransExeTime());
            //System.out.println ("ResultCode: " + result.getBody().getTXLifeResponse().getTransResult().getResultCode().get$());

        } catch ( AlipcontractException e ) {
        	System.err.println("Exception: " + e.getMessage());
            System.err.println("ERROR: " + e.getStatusCode() + " " + e.getReason());
            System.err.println("ERROR: " + e.getResponse().toString());
            e.printStackTrace();
            
        }
    }
    
}