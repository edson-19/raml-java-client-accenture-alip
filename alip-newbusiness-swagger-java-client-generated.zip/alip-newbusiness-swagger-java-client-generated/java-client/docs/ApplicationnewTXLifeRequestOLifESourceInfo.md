
# ApplicationnewTXLifeRequestOLifESourceInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sourceInfoName** | **String** |  |  [optional]
**olifEExtension** | [**List&lt;ApplicationnewTXLifeRequestOLifESourceInfoOlifEExtension&gt;**](ApplicationnewTXLifeRequestOLifESourceInfoOlifEExtension.md) |  |  [optional]



