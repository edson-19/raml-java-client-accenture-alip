# DefaultApi

All URIs are relative to *http://alipmule.eastus.cloudapp.azure.com/alip-transactions*

Method | HTTP request | Description
------------- | ------------- | -------------
[**contractsIdTransactionsPost**](DefaultApi.md#contractsIdTransactionsPost) | **POST** /contracts/{id}/transactions | 
[**paymentRejectTransactionPost**](DefaultApi.md#paymentRejectTransactionPost) | **POST** /PaymentReject/Transaction | 
[**suspenseContractPost**](DefaultApi.md#suspenseContractPost) | **POST** /Suspense/contract | 
[**transactionsContractIdAvailableGet**](DefaultApi.md#transactionsContractIdAvailableGet) | **GET** /transactions/contract/{id}/available | 
[**transactionsContractIdHistoryGet**](DefaultApi.md#transactionsContractIdHistoryGet) | **GET** /transactions/contract/{id}/history/ | 
[**transactionsContractIdHistoryStartDateEndDateGet**](DefaultApi.md#transactionsContractIdHistoryStartDateEndDateGet) | **GET** /transactions/contract/{id}/history/{startDate}/{endDate} | 
[**transactionsContractIdHistoryStartDateGet**](DefaultApi.md#transactionsContractIdHistoryStartDateGet) | **GET** /transactions/contract/{id}/history/{startDate}/ | 


<a name="contractsIdTransactionsPost"></a>
# **contractsIdTransactionsPost**
> contractsIdTransactionsPost(id, generated)



Withdrawal/Loan/Rebalance/Fund Transfer Request API

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String id = "id_example"; // String | Contract Number
ERRORUNKNOWN generated = new ERRORUNKNOWN(); // ERRORUNKNOWN | 
try {
    apiInstance.contractsIdTransactionsPost(id, generated);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#contractsIdTransactionsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Contract Number |
 **generated** | [**ERRORUNKNOWN**](ERRORUNKNOWN.md)|  | [optional]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="paymentRejectTransactionPost"></a>
# **paymentRejectTransactionPost**
> ERRORUNKNOWN paymentRejectTransactionPost(generated)



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
ERRORUNKNOWN generated = new ERRORUNKNOWN(); // ERRORUNKNOWN | 
try {
    ERRORUNKNOWN result = apiInstance.paymentRejectTransactionPost(generated);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#paymentRejectTransactionPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **generated** | [**ERRORUNKNOWN**](ERRORUNKNOWN.md)|  | [optional]

### Return type

[**ERRORUNKNOWN**](ERRORUNKNOWN.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="suspenseContractPost"></a>
# **suspenseContractPost**
> ERRORUNKNOWN suspenseContractPost(generated)



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
ERRORUNKNOWN generated = new ERRORUNKNOWN(); // ERRORUNKNOWN | 
try {
    ERRORUNKNOWN result = apiInstance.suspenseContractPost(generated);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#suspenseContractPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **generated** | [**ERRORUNKNOWN**](ERRORUNKNOWN.md)|  | [optional]

### Return type

[**ERRORUNKNOWN**](ERRORUNKNOWN.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="transactionsContractIdAvailableGet"></a>
# **transactionsContractIdAvailableGet**
> ERRORUNKNOWN transactionsContractIdAvailableGet(id)



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String id = "id_example"; // String | Contract Number
try {
    ERRORUNKNOWN result = apiInstance.transactionsContractIdAvailableGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#transactionsContractIdAvailableGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Contract Number |

### Return type

[**ERRORUNKNOWN**](ERRORUNKNOWN.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="transactionsContractIdHistoryGet"></a>
# **transactionsContractIdHistoryGet**
> ERRORUNKNOWN transactionsContractIdHistoryGet(id)



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String id = "id_example"; // String | Contract Number
try {
    ERRORUNKNOWN result = apiInstance.transactionsContractIdHistoryGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#transactionsContractIdHistoryGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Contract Number |

### Return type

[**ERRORUNKNOWN**](ERRORUNKNOWN.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="transactionsContractIdHistoryStartDateEndDateGet"></a>
# **transactionsContractIdHistoryStartDateEndDateGet**
> ERRORUNKNOWN transactionsContractIdHistoryStartDateEndDateGet(id, startDate, endDate)



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String id = "id_example"; // String | Contract Number
String startDate = "startDate_example"; // String | yyyymmdd
String endDate = "endDate_example"; // String | yyyymmdd
try {
    ERRORUNKNOWN result = apiInstance.transactionsContractIdHistoryStartDateEndDateGet(id, startDate, endDate);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#transactionsContractIdHistoryStartDateEndDateGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Contract Number |
 **startDate** | **String**| yyyymmdd |
 **endDate** | **String**| yyyymmdd |

### Return type

[**ERRORUNKNOWN**](ERRORUNKNOWN.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="transactionsContractIdHistoryStartDateGet"></a>
# **transactionsContractIdHistoryStartDateGet**
> ERRORUNKNOWN transactionsContractIdHistoryStartDateGet(id, startDate)



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String id = "id_example"; // String | Contract Number
String startDate = "startDate_example"; // String | yyyymmdd
try {
    ERRORUNKNOWN result = apiInstance.transactionsContractIdHistoryStartDateGet(id, startDate);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#transactionsContractIdHistoryStartDateGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Contract Number |
 **startDate** | **String**| yyyymmdd |

### Return type

[**ERRORUNKNOWN**](ERRORUNKNOWN.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

