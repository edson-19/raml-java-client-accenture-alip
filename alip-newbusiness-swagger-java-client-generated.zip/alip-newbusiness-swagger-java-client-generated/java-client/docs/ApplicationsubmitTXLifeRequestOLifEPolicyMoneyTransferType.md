
# ApplicationsubmitTXLifeRequestOLifEPolicyMoneyTransferType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tc** | [**TcEnum**](#TcEnum) |  |  [optional]
**value** | **String** |  |  [optional]


<a name="TcEnum"></a>
## Enum: TcEnum
Name | Value
---- | -----
_1 | &quot;1&quot;
_3 | &quot;3&quot;
_4 | &quot;4&quot;



