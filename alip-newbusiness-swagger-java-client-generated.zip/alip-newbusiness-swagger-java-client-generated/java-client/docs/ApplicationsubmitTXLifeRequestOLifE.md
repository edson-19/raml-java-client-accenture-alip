
# ApplicationsubmitTXLifeRequestOLifE

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **String** |  |  [optional]
**holding** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEHolding&gt;**](ApplicationsubmitTXLifeRequestOLifEHolding.md) |  | 
**party** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEParty&gt;**](ApplicationsubmitTXLifeRequestOLifEParty.md) |  | 
**relation** | [**List&lt;ApplicationsubmitTXLifeRequestOLifERelation&gt;**](ApplicationsubmitTXLifeRequestOLifERelation.md) |  | 
**olifEExtension** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEPolicyOLifEExtension&gt;**](ApplicationsubmitTXLifeRequestOLifEPolicyOLifEExtension.md) |  |  [optional]



