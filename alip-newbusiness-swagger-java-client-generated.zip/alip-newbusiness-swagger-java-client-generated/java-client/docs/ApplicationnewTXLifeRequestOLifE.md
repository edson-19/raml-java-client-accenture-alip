
# ApplicationnewTXLifeRequestOLifE

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **String** |  |  [optional]
**sourceInfo** | [**ApplicationnewTXLifeRequestOLifESourceInfo**](ApplicationnewTXLifeRequestOLifESourceInfo.md) |  |  [optional]
**holding** | [**List&lt;ApplicationnewTXLifeRequestOLifEHolding&gt;**](ApplicationnewTXLifeRequestOLifEHolding.md) |  | 
**party** | [**List&lt;ApplicationnewTXLifeRequestOLifEParty&gt;**](ApplicationnewTXLifeRequestOLifEParty.md) |  | 
**relation** | [**List&lt;ApplicationsubmitTXLifeRequestOLifERelation&gt;**](ApplicationsubmitTXLifeRequestOLifERelation.md) |  | 
**formInstance** | [**List&lt;ApplicationnewTXLifeRequestOLifEFormInstance&gt;**](ApplicationnewTXLifeRequestOLifEFormInstance.md) |  |  [optional]
**olifEExtension** | [**List&lt;ApplicationnewTXLifeRequestOLifESourceInfoOlifEExtension&gt;**](ApplicationnewTXLifeRequestOLifESourceInfoOlifEExtension.md) |  |  [optional]



