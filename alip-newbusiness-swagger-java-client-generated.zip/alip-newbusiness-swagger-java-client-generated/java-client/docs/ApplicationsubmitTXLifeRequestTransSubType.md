
# ApplicationsubmitTXLifeRequestTransSubType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tc** | [**TcEnum**](#TcEnum) |  |  [optional]
**value** | **String** |  |  [optional]


<a name="TcEnum"></a>
## Enum: TcEnum
Name | Value
---- | -----
_10302 | &quot;10302&quot;



