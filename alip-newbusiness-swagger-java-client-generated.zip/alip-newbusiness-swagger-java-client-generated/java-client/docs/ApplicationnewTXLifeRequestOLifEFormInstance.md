
# ApplicationnewTXLifeRequestOLifEFormInstance

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**formName** | **String** |  |  [optional]
**primaryFormInd** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**id** | **String** |  |  [optional]
**relatedObjectID** | **String** |  |  [optional]



