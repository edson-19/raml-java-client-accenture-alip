
# ApplicationsubmitTXLifeRequestOLifEArrSource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subAcctID** | **String** |  |  [optional]
**productCode** | **String** |  |  [optional]
**transferPct** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



