
# ApplicationnewTXLifeRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**primaryObjectID** | **String** |  |  [optional]
**transRefGUID** | **String** |  | 
**transType** | [**ApplicationsubmitTXLifeRequestTransType**](ApplicationsubmitTXLifeRequestTransType.md) |  | 
**transSubType** | [**ApplicationnewTXLifeRequestTransSubType**](ApplicationnewTXLifeRequestTransSubType.md) |  | 
**transExeDate** | **String** |  | 
**transExeTime** | **String** |  | 
**olifE** | [**ApplicationnewTXLifeRequestOLifE**](ApplicationnewTXLifeRequestOLifE.md) |  | 



