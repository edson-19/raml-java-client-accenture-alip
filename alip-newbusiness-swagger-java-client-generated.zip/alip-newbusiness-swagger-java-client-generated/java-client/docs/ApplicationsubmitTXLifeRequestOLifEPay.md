
# ApplicationsubmitTXLifeRequestOLifEPay

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payrollDeduction** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEPayrollDeduction&gt;**](ApplicationsubmitTXLifeRequestOLifEPayrollDeduction.md) |  |  [optional]



