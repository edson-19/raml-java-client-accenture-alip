
# ApplicationsubmitTXLifeRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**primaryObjectID** | **String** |  |  [optional]
**transRefGUID** | **String** |  | 
**transType** | [**ApplicationsubmitTXLifeRequestTransType**](ApplicationsubmitTXLifeRequestTransType.md) |  | 
**transSubType** | [**ApplicationsubmitTXLifeRequestTransSubType**](ApplicationsubmitTXLifeRequestTransSubType.md) |  | 
**transExeDate** | **String** |  | 
**transExeTime** | **String** |  | 
**olifE** | [**ApplicationsubmitTXLifeRequestOLifE**](ApplicationsubmitTXLifeRequestOLifE.md) |  | 



