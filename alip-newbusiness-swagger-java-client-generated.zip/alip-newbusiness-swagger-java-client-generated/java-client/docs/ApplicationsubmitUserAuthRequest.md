
# ApplicationsubmitUserAuthRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userLoginName** | **String** |  |  [optional]



