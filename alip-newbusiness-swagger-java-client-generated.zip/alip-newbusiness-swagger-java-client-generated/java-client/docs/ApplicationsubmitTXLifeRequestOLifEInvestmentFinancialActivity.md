
# ApplicationsubmitTXLifeRequestOLifEInvestmentFinancialActivity

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**finActivityType** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]



