
import org.mule.example.api.AliptransactionClient;
import org.mule.example.exceptions.AliptransactionException;
import org.mule.example.resource.transactions.contract.id.history.startDate.endDate.model.*;
import org.mule.example.responses.AliptransactionResponse;

public class GetHistoryTransactionsExample {
    public static void main(String[] args) {
        try {
			final AliptransactionResponse<EndDateGETResponseBody> result = 
					AliptransactionClient.create("http://10.6.44.198:8080/relrt12wsgateway/api/ext-portal")
            		.transactions.contract.id("07675").history.startDate("").endDate("").get();
               		
            System.out.println ("TransRefGUID: " + result.getBody().getTXLife().getTXLifeResponse().getTransRefGUID());
            System.out.println ("TransExeDate: " + result.getBody().getTXLife().getTXLifeResponse().getTransExeDate());
            System.out.println ("TransExeTime: " + result.getBody().getTXLife().getTXLifeResponse().getTransExeTime());
            System.out.println ("ResultCode: " + result.getBody().getTXLife().getTXLifeResponse().getTransResult().getResultCode().get$());

        } catch ( AliptransactionException e ) {
        	System.err.println("Exception: " + e.getMessage());
            System.err.println("ERROR: " + e.getStatusCode() + " " + e.getReason());
            System.err.println("ERROR: " + e.getResponse().toString());
            e.printStackTrace();
            
        }
    }
    
}