/**
import org.mule.example.api.ClientAPIClient;
import org.mule.example.exceptions.ClientAPIException;
import org.mule.example.resource.users.userId.model.UserIdGETResponseBody;
import org.mule.example.responses.ClientAPIResponse;

import org.mule.example.api.AlipagentClient;
import org.mule.example.exceptions.AlipagentException;
import org.mule.example.resource.agents.id.summary.model.SummaryGETResponseBody;
import org.mule.example.resource.agents.id.summary.model.SummaryGETQueryParam;
import org.mule.example.responses.AlipagentResponse;

import org.mule.example.api.AlipbankingClient;
import org.mule.example.exceptions.AlipbankingException;
import org.mule.example.resource.customers.id.accounts.model.AccountsGETResponseBody;
import org.mule.example.resource.customers.id.accounts.model.AccountsGETQueryParam;
import org.mule.example.responses.AlipbankingResponse;
**/

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.mule.example.api.AlipnewbusinessClient;
import org.mule.example.exceptions.AlipnewbusinessException;
//import org.mule.example.resource.agents.id.dashboard.applications.startDate.endDate.model.EndDateGETResponseBody;

import org.mule.example.resource.application.submit.model.*;

import org.mule.example.responses.AlipnewbusinessResponse;

import com.fasterxml.jackson.databind.ObjectMapper;


public class ClientExample {
    public static void main(String[] args) {
        try {
            //final ClientAPIResponse<UserIdGETResponseBody> result = ClientAPIClient.create().users.userId("luis").get();
            //final AlipagentResponse<SummaryGETResponseBody> result = AlipagentClient.create().agents.id("131").
            //	summary.get(new SummaryGETQueryParam("clientSecret", "clientId"));
            //final AlipbankingResponse<AccountsGETResponseBody> result = AlipbankingClient.create().customers.id("1172").
            //	accounts.get(new AccountsGETQueryParam("clientSecret", "clientId"));
            //final AlipnewbusinessResponse<EndDateGETResponseBody> result = 
            //	AlipnewbusinessClient.create().agents.id("navy01")
            //		.dashboard.applications.startDate("20170101").endDate("20181231")
            //   		.get();
        	input();
            final AlipnewbusinessResponse<SubmitPOSTResponseBody> result = 
                	AlipnewbusinessClient.create("http://10.6.44.198:8080/relrt12wsgateway/api/ext-portal")
                	.application.submit.post(body());
            
            System.out.println ("TransRefGUID: " + result.getBody().getTXLife().getTXLifeResponse().getTransRefGUID());
            System.out.println ("TransExeDate: " + result.getBody().getTXLife().getTXLifeResponse().getTransExeDate());
            System.out.println ("TransExeTime: " + result.getBody().getTXLife().getTXLifeResponse().getTransExeTime());
            System.out.println ("ResultCode: " + result.getBody().getTXLife().getTXLifeResponse().getTransResult().getResultCode().get$());
            //System.out.println ("BankName: " + result.getBody().getTXLife().getTXLifeResponse().getOLifE().getHolding().get(0).getBanking().getBankName());
        //} catch ( ClientAPIException e ) {
        //} catch ( AlipagentException e ) {
        //} catch ( AlipbankingException e ) {
        } catch ( AlipnewbusinessException e ) {
            System.err.println("ERROR: " + e.getStatusCode() + " " + e.getReason());
            System.err.println("ERROR: " + e.getResponse().toString());
            
        }
    }
    
    public static SubmitPOSTBody body() {
    	SubmitPOSTBody body;
    	String json = input(); //json();
        ObjectMapper mapper = new ObjectMapper();
        try {
        	body = mapper.readValue(json, SubmitPOSTBody.class);
            
        	System.out.println("REQUEST: " + body.toString());
            System.out.println("UserLoginName: " + body.getTXLife().getUserAuthRequest().getUserLoginName());
            System.out.println("TransRefGUID: " + body.getTXLife().getTXLifeRequest().getTransRefGUID());
            System.out.println("DraftDate: " + body.getTXLife().getTXLifeRequest().getOLifE().getHolding().get(0).getPolicy().getOLifEExtension().getDraftDate());
            
    		return body;
        } catch (IOException e) {
            e.printStackTrace();
        }
		return null;
    	
    }
    
    public static String input(){
      String input = null;
      StringBuilder builder = new StringBuilder();
      FileReader fr = null;
      BufferedReader br = null;
      try {
    	fr = new FileReader("src\\test\\java\\nb_submit_req.json");
    	br = new BufferedReader(fr);
    	String sCurrentLine;
		while ((sCurrentLine = br.readLine()) != null) {
			//System.out.println(sCurrentLine);
			builder.append(sCurrentLine);
		}
    	fr.close();
    	br.close();
      } catch (IOException e) {
    	  e.printStackTrace();
      } 
      //System.out.println("input: " + input);
      input = builder.toString();
      return input;
    }
    

	public static SubmitPOSTBody request() {
    	SubmitPOSTBody request = new SubmitPOSTBody();
    	TXLife tXLife = new TXLife();
    	tXLife.setUserAuthRequest(new UserAuthRequest("SUPERVIS"));
    	TXLifeRequest tXLifeRequest = new TXLifeRequest();
    	tXLifeRequest.setTransExeDate("2019-02-05");
    	tXLifeRequest.setTransExeTime("19:27:14");
    	tXLifeRequest.setTransRefGUID("44a71996-31b4-7cd9-3a6e-aa87745a1111");
    	tXLifeRequest.setTransType(new TransType("103", "New Business Submit"));
    	tXLifeRequest.setTransSubType(new TransSubType("10302", "New Business Submit"));
    	OLifE oLifE = new OLifE();
    	Holding holding = new Holding();
    	holding.setHoldingTypeCode(new HoldingTypeCode("2", "Policy"));
    	Policy policy = new Policy();
    	policy.setProductType(new ProductType("10", "Deferred Annuity"));
    	policy.setProductCode("15");
    	policy.setCarrierCode("Default Company");
    	policy.setPlanName("Variable Annuity");
    	policy.setJurisdiction(new Jurisdiction("37", "NY"));
    	policy.setEffDate("2019-02-05");
    	policy.setMinPremiumInitialAmt("10000");
    	policy.setPaymentMode(new PaymentMode("1", "Annual"));
    	policy.setPaymentAmt("10000.00");
    	Annuity annuity = new Annuity();
    	annuity.setQualPlanType(new QualPlanType("1", "Non-Qualified"));
    	annuity.setInitDepositDate("2019-02-05");
    	Payout payout = new Payout();
    	payout.setAnnuityStartingDate("2055-07-26");
    	payout.setPayoutMode(new PayoutMode("1", "Annual"));
    	annuity.setPayout(payout);
    	policy.setAnnuity(annuity);
    	ApplicationInfo appinfo = new ApplicationInfo();
    	appinfo.setApplicationJurisdiction(new ApplicationJurisdiction("37", "NY"));
    	appinfo.setSignedDate("2019-02-05");
    	appinfo.setSignatureInfo(new SignatureInfo("2019-02-05"));
    	policy.setApplicationInfo(appinfo);
    	policy.setOLifEExtension(new OLifEExtension("15000.00", "2019-02-05"));
    	holding.setPolicy(policy);
    	Investment investment = new Investment();
    	SubAccount subAccount = new SubAccount();
    	subAccount.setId("PremiumFund_1");
    	subAccount.setProductCode("0A-03");
    	subAccount.setProductFullName("General Account");
    	subAccount.setInvestType(new InvestType("20","Fixed Fund"));
    	subAccount.setAllocPercent("100");
    	FinancialActivity finact = new FinancialActivity();
    	finact.setFinActivityType(new FinActivityType("1", "General Account"));
    	subAccount.setFinancialActivity(finact);
    	investment.setSubAccount(subAccount);
    	holding.setInvestment(investment);
    	
    	oLifE.getHolding().add(holding);
    	Party party = new Party();
    	party.setId("Party_PrimaryAnnuitant");
    	party.setPartyTypeCode(new PartyTypeCode("1", "Person"));
    	party.setFullName("David Romeo");
    	party.setGovtID("786765124");
    	party.setGovtIDTC(new GovtIDTC("1", "Social Security Number US"));
    	party.setGovtIDCertificationDate("2008-01-01");
    	party.setResidenceCountry(new ResidenceCountry("1", "USA"));
    	Person person = new Person();
    	person.setFirstName("David");
    	person.setMiddleName("K");
    	person.setLastName("Romeo");
    	person.setPrefix("Mr.");
    	person.setMarStat(new MarStat("1", "Married"));
    	person.setGender(new Gender("1", "Male"));
    	person.setBirthDate("1988-01-01");
    	person.setCitizenship(new Citizenship("1", "USA"));
    	person.setEstGrossAnnualOtherIncome("96000");
    	person.setNonResidentAlienInd(new NonResidentAlienInd("0", "False"));
    	person.setOccupation("Technology and Computer Sciences");
    	
    	person.setOLifEExtension(new OLifEExtension_(
    			new BackupWithholdingIndicator("0", "false"), 
    			new EDeliveryOptOutOptionIndicator("0", "false"), 
    			"2016-01-01"));

    	party.setPerson(person);
    	Address address = new Address();
    	address.setAddressTypeCode(new AddressTypeCode("0", "Mailing"));
    	address.setLine1("100 Main Street5");
    	address.setLine2("Phoenix");
    	address.setLine3("line3");
    	address.setCity("Morris Plains");
    	address.setAddressStateTC(new AddressStateTC("37", "NY"));
    	address.setZip("07950");
    	address.setAddressCountryTC(new AddressCountryTC("1", "USA"));
    	address.setPrefAddr(new PrefAddr("1", "true"));
    	address.setSolicitationInd(new SolicitationInd("0", "false"));
    	address.setAddressValidInd(new AddressValidInd("1", "true"));
    	party.setAddress(address);
    	Phone phone = new Phone();
    	phone.setPhoneTypeCode(new PhoneTypeCode("1", "Home"));
    	phone.setAreaCode("555");
    	phone.setDialNumber("1233332");
    	phone.setSolicitationInd(new SolicitationInd_("0", "false"));
    	party.setPhone(phone);
    	EMailAddress eMailAddress = new EMailAddress();
    	eMailAddress.setEMailType(new EMailType("5", "Primary"));
    	eMailAddress.setAddrLine("david.romeo@gmail.com");
    	eMailAddress.setSolicitationInd(new SolicitationInd__("1", "true"));
    	party.setEMailAddress(eMailAddress);
    	oLifE.getParty().add(party);
    	Relation relation = new Relation();
    	relation.setOriginatingObjectID("Holding_ProposedPolicy");
    	relation.setRelatedObjectID("Party_Agent");
    	relation.setId("R_Agent_to_Holding");
    	relation.setOriginatingObjectType(new OriginatingObjectType("4", "Holding"));
    	relation.setRelatedObjectType(new RelatedObjectType("6", "Party"));
    	relation.setRelationRoleCode(new RelationRoleCode("37", "Agent of Record"));
    	oLifE.getRelation().add(relation);
    	tXLifeRequest.setOLifE(oLifE);
    	tXLife.setTXLifeRequest(tXLifeRequest);
    	request.setTXLife(tXLife);
    	
		return request;
    }
    
    private static String json() {
		return "{" + 
				"   \"TXLife\": {" + 
				"      \"UserAuthRequest\": {" + 
				"         \"UserLoginName\": \"SUPERVIS\"" + 
				"      }," + 
				"      \"TXLifeRequest\": {" + 
				"         \"TransRefGUID\": \"44a71996-31b4-7cd9-3a6e-aa87745a0040\"," + 
				"         \"TransType\": {" + 
				"            \"@tc\": \"103\"," + 
				"            \"$\": \"New Business Submit\"" + 
				"         }," + 
				"         \"TransSubType\": {" + 
				"            \"@tc\": \"10302\"," + 
				"            \"$\": \"New Business Submit\"" + 
				"         }," + 
				"         \"TransExeDate\": \"2019-02-05\"," + 
				"         \"TransExeTime\": \"19:27:14\"," + 
				"         \"OLifE\": {" + 
				"            \"Holding\": [" + 
				"               {" + 
				"                  \"@id\": \"Holding_ProposedPolicy\"," + 
				"                  \"HoldingTypeCode\": {" + 
				"                     \"@tc\": \"2\"," + 
				"                     \"$\": \"Policy\"" + 
				"                  }," + 
				"                  \"Policy\": {" + 
				"                     \"ProductType\": {" + 
				"                        \"@tc\": \"10\"," + 
				"                        \"$\": \"Deferred Annuity\"" + 
				"                     }," + 
				"                     \"ProductCode\": \"15\"," + 
				"                     \"CarrierCode\": \"Default Company\"," + 
				"                     \"PlanName\": \"Variable Annuity\"," + 
				"                     \"Jurisdiction\": {" + 
				"                        \"@tc\": \"37\"," + 
				"                        \"$\": \"NY\"" + 
				"                     }," + 
				"                     \"EffDate\": \"2019-02-05\"," + 
				"                     \"MinPremiumInitialAmt\": \"10000\"," + 
				"                     \"PaymentMode\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"Annual\"" + 
				"                     }," + 
				"                     \"PaymentAmt\": \"10000.00\"," + 
				"                     \"Annuity\": {" + 
				"                        \"QualPlanType\": {" + 
				"                           \"@tc\": \"1\"," + 
				"                           \"$\": \"Non-Qualified\"" + 
				"                        }," + 
				"                        \"InitDepositDate\": \"2019-02-05\"," + 
				"                        \"Payout\": {" + 
				"                           \"AnnuityStartingDate\": \"2055-07-26\"," + 
				"                           \"PayoutMode\": {" + 
				"                              \"@tc\": \"1\"," + 
				"                              \"$\": \"Annual\"" + 
				"                           }" + 
				"                        }" + 
				"                     }," + 
				"                     \"ApplicationInfo\": {" + 
				"                        \"ApplicationJurisdiction\": {" + 
				"                           \"@tc\": \"37\"," + 
				"                           \"$\": \"NY\"" + 
				"                        }," + 
				"                        \"SignedDate\": \"2019-02-05\"," + 
				"                        \"SignatureInfo\": {" + 
				"                           \"SignatureDate\": \"2019-02-05\"" + 
				"                        }" + 
				"                     }," + 
				"                     \"OLifEExtension\": {" + 
				"                        \"InitDepositAmt\": \"15000.00\"," + 
				"                        \"DraftDate\": \"2019-02-05\"" + 
				"                     }" + 
				"                  }," + 
				"                  \"Investment\": {" + 
				"                     \"SubAccount\": {" + 
				"                        \"@id\": \"PremiumFund_1\"," + 
				"                        \"ProductCode\": \"0A-03\"," + 
				"                        \"ProductFullName\": \"General Account\"," + 
				"                        \"InvestType\": {" + 
				"                           \"@tc\": \"20\"," + 
				"                           \"$\": \"Fixed Fund\"" + 
				"                        }," + 
				"                        \"AllocPercent\": \"100\"," + 
				"                        \"FinancialActivity\": {" + 
				"                           \"FinActivityType\": {" + 
				"                              \"@tc\": \"1\"," + 
				"                              \"$\": \"General Account\"" + 
				"                           }" + 
				"                        }" + 
				"                     }" + 
				"                  }" + 
				"               }," + 
				"               {" + 
				"                  \"@id\": \"Holding_Banking\"," + 
				"                  \"HoldingTypeCode\": {" + 
				"                     \"@tc\": \"7\"," + 
				"                     \"$\": \"Banking\"" + 
				"                  }," + 
				"                  \"Banking\": {" + 
				"                     \"BankAcctType\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"Saving Account\"" + 
				"                     }," + 
				"                     \"AccountNumber\": \"1234567489\"," + 
				"                     \"RoutingNum\": \"321171184\"," + 
				"                     \"AcctHolderName\": \"Ms. Bank Test11\"," + 
				"                     \"BankName\": \"Bank of California\"" + 
				"                  }" + 
				"               }" + 
				"            ]," + 
				"            \"Party\": [" + 
				"               {" + 
				"                  \"@id\": \"Party_PrimaryAnnuitant\"," + 
				"                  \"PartyTypeCode\": {" + 
				"                     \"@tc\": \"1\"," + 
				"                     \"$\": \"Person\"" + 
				"                  }," + 
				"                  \"FullName\": \"David Romeo\"," + 
				"                  \"GovtID\": \"786765124\"," + 
				"                  \"GovtIDTC\": {" + 
				"                     \"@tc\": \"1\"," + 
				"                     \"$\": \"Social Security Number US\"" + 
				"                  }," + 
				"                  \"GovtIDCertificationDate\": \"2008-01-01\"," + 
				"                  \"ResidenceCountry\": {" + 
				"                     \"@tc\": \"1\"," + 
				"                     \"$\": \"USA\"" + 
				"                  }," + 
				"                  \"Person\": {" + 
				"                     \"FirstName\": \"David\"," + 
				"                     \"MiddleName\": \"K\"," + 
				"                     \"LastName\": \"Romeo\"," + 
				"                     \"Prefix\": \"Mr.\"," + 
				"                     \"MarStat\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"Married\"" + 
				"                     }," + 
				"                     \"Gender\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"Male\"" + 
				"                     }," + 
				"                     \"BirthDate\": \"1988-01-01\"," + 
				"                     \"Citizenship\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"USA\"" + 
				"                     }," + 
				"                     \"EstGrossAnnualOtherIncome\": \"96000\"," + 
				"                     \"NonResidentAlienInd\": {" + 
				"                        \"@tc\": \"0\"," + 
				"                        \"$\": \"False\"" + 
				"                     }," + 
				"                     \"Occupation\": \"Technology and Computer Sciences\"," + 
				"                     \"OLifEExtension\": {" + 
				"                        \"BackupWithholdingIndicator\": {" + 
				"                           \"@tc\": \"0\"," + 
				"                           \"$\": \"false\"" + 
				"                        }," + 
				"                        \"eDeliveryOptOutOptionIndicator\": {" + 
				"                           \"@tc\": \"0\"," + 
				"                           \"$\": \"false\"" + 
				"                        }," + 
				"                        \"BDValidationDate\": \"2016-01-01\"" + 
				"                     }" + 
				"                  }," + 
				"                  \"Address\": {" + 
				"                     \"AddressTypeCode\": {" + 
				"                        \"@tc\": \"0\"," + 
				"                        \"$\": \"Mailing\"" + 
				"                     }," + 
				"                     \"Line1\": \"100 Main Street5\"," + 
				"                     \"Line2\": \"Phoenix\"," + 
				"                     \"Line3\": \"line3\"," + 
				"                     \"City\": \"Morris Plains\"," + 
				"                     \"AddressStateTC\": {" + 
				"                        \"@tc\": \"37\"," + 
				"                        \"$\": \"NY\"" + 
				"                     }," + 
				"                     \"Zip\": \"07950\"," + 
				"                     \"AddressCountryTC\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"USA\"" + 
				"                     }," + 
				"                     \"PrefAddr\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"true\"" + 
				"                     }," + 
				"                     \"SolicitationInd\": {" + 
				"                        \"@tc\": \"0\"," + 
				"                        \"$\": \"false\"" + 
				"                     }," + 
				"                     \"PostalDropCode\": []," + 
				"                     \"AddressValidInd\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"true\"" + 
				"                     }" + 
				"                  }," + 
				"                  \"Phone\": {" + 
				"                     \"PhoneTypeCode\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"Home\"" + 
				"                     }," + 
				"                     \"AreaCode\": \"555\"," + 
				"                     \"DialNumber\": \"1233332\"," + 
				"                     \"SolicitationInd\": {" + 
				"                        \"@tc\": \"0\"," + 
				"                        \"$\": \"false\"" + 
				"                     }" + 
				"                  }," + 
				"                  \"EMailAddress\": {" + 
				"                     \"EMailType\": {" + 
				"                        \"@tc\": \"5\"," + 
				"                        \"$\": \"Primary\"" + 
				"                     }," + 
				"                     \"AddrLine\": \"david.romeo@gmail.com\"," + 
				"                     \"SolicitationInd\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"true\"" + 
				"                     }" + 
				"                  }" + 
				"               }," + 
				"               {" + 
				"                  \"@id\": \"Party_Agent\"," + 
				"                  \"PartyTypeCode\": {" + 
				"                     \"@tc\": \"1\"," + 
				"                     \"$\": \"Person\"" + 
				"                  }," + 
				"                  \"Person\": {" + 
				"                     \"FirstName\": \"John\"," + 
				"                     \"LastName\": \"Miller\"" + 
				"                  }," + 
				"                  \"Producer\": {" + 
				"                     \"NIPRNumber\": \"VL730\"" + 
				"                  }," + 
				"                  \"EMailAddress\": {" + 
				"                     \"AddrLine\": \"ajames@gmail.com\"" + 
				"                  }" + 
				"               }," + 
				"               {" + 
				"                  \"@id\": \"Party_Joint_Owner_Company\"," + 
				"                  \"PartyTypeCode\": {" + 
				"                     \"@tc\": \"2\"," + 
				"                     \"$\": \"Organization\"" + 
				"                  }," + 
				"                  \"FullName\": \"Revive Inn\"," + 
				"                  \"GovtID\": \"452233211\"," + 
				"                  \"GovtIDTC\": {" + 
				"                     \"@tc\": \"2\"," + 
				"                     \"$\": \"Taxpayer Identification Number\"" + 
				"                  }," + 
				"                  \"GovtIDCertificationDate\": \"2008-01-01\"," + 
				"                  \"ResidenceCountry\": {" + 
				"                     \"@tc\": \"1\"," + 
				"                     \"$\": \"USA\"" + 
				"                  }," + 
				"                  \"Organization\": {" + 
				"                     \"OrgForm\": {" + 
				"                        \"@tc\": \"23\"," + 
				"                        \"$\": \"Organization\"" + 
				"                     }" + 
				"                  }," + 
				"                  \"Address\": {" + 
				"                     \"AddressTypeCode\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"Residence\"" + 
				"                     }," + 
				"                     \"Line1\": \"100 Main Street\"," + 
				"                     \"Line2\": \"aaaa\"," + 
				"                     \"Line3\": \"bbbb\"," + 
				"                     \"City\": \"Avenel\"," + 
				"                     \"AddressStateTC\": {" + 
				"                        \"@tc\": \"37\"," + 
				"                        \"$\": \"NY\"" + 
				"                     }," + 
				"                     \"Zip\": \"07001\"," + 
				"                     \"AddressCountryTC\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"USA\"" + 
				"                     }," + 
				"                     \"PrefAddr\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"true\"" + 
				"                     }," + 
				"                     \"SolicitationInd\": {" + 
				"                        \"@tc\": \"0\"," + 
				"                        \"$\": \"false\"" + 
				"                     }," + 
				"                     \"PostalDropCode\": []," + 
				"                     \"AddressValidInd\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"true\"" + 
				"                     }" + 
				"                  }," + 
				"                  \"Phone\": " + //[" + 
				"                     {" + 
				"                        \"PhoneTypeCode\": {" + 
				"                           \"@tc\": \"2147483647\"," + 
				"                           \"$\": \"Phone One\"" + 
				"                        }," + 
				"                        \"AreaCode\": \"414\"," + 
				"                        \"DialNumber\": \"7878788\"," + 
				"                        \"SolicitationInd\": {" + 
				"                           \"@tc\": \"0\"," + 
				"                           \"$\": \"false\"" + 
				"                        }" + 
				"                     }," + 
//				"                     {" + 
//				"                        \"PhoneTypeCode\": {" + 
//				"                           \"@tc\": \"0\"," + 
//				"                           \"$\": \"Contact Phone\"" + 
//				"                        }," + 
//				"                        \"AreaCode\": \"555\"," + 
//				"                        \"DialNumber\": \"7878788\"," + 
//				"                        \"SolicitationInd\": {" + 
//				"                           \"@tc\": \"0\"," + 
//				"                           \"$\": \"false\"" + 
//				"                        }" + 
//				"                     }" + 
//				"                  ]," + 
				"                  \"EMailAddress\": {" + 
				"                     \"EMailType\": {" + 
				"                        \"@tc\": \"5\"," + 
				"                        \"$\": \"Primary\"" + 
				"                     }," + 
				"                     \"AddrLine\": \"rob@gmail.com\"," + 
				"                     \"SolicitationInd\": {" + 
				"                        \"@tc\": \"0\"," + 
				"                        \"$\": \"false\"" + 
				"                     }" + 
				"                  }," + 
				"                  \"OLifEExtension\": {" + 
				"                     \"BeneficiaryContactName\": \"Soyab Malpura\"," + 
				"                     \"BeneficiaryToOwnerRelation\": \"Friend\"" + 
				"                  }" + 
				"               }," + 
				"               {" + 
				"                  \"@id\": \"Party_Joint_Owner_Individual\"," + 
				"                  \"PartyTypeCode\": {" + 
				"                     \"@tc\": \"1\"," + 
				"                     \"$\": \"Person\"" + 
				"                  }," + 
				"                  \"FullName\": \"Saurabh Kale\"," + 
				"                  \"GovtID\": \"784662124\"," + 
				"                  \"GovtIDTC\": {" + 
				"                     \"@tc\": \"1\"," + 
				"                     \"$\": \"Social Security Number US\"" + 
				"                  }," + 
				"                  \"GovtIDCertificationDate\": \"2008-01-01\"," + 
				"                  \"ResidenceCountry\": {" + 
				"                     \"@tc\": \"1\"," + 
				"                     \"$\": \"USA\"" + 
				"                  }," + 
				"                  \"Person\": {" + 
				"                     \"FirstName\": \"Saurabh\"," + 
				"                     \"MiddleName\": \"K\"," + 
				"                     \"LastName\": \"Kale\"," + 
				"                     \"Prefix\": \"Mr.\"," + 
				"                     \"MarStat\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"Married\"" + 
				"                     }," + 
				"                     \"Gender\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"Male\"" + 
				"                     }," + 
				"                     \"BirthDate\": \"1980-01-01\"," + 
				"                     \"Citizenship\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"USA\"" + 
				"                     }," + 
				"                     \"EstGrossAnnualOtherIncome\": \"96000\"," + 
				"                     \"NonResidentAlienInd\": {" + 
				"                        \"@tc\": \"0\"," + 
				"                        \"$\": \"False\"" + 
				"                     }," + 
				"                     \"Occupation\": \"Technology and Computer Sciences\"," + 
				"                     \"OLifEExtension\": {" + 
				"                        \"BackupWithholdingIndicator\": {" + 
				"                           \"@tc\": \"0\"," + 
				"                           \"$\": \"false\"" + 
				"                        }," + 
				"                        \"eDeliveryOptOutOptionIndicator\": {" + 
				"                           \"@tc\": \"0\"," + 
				"                           \"$\": \"false\"" + 
				"                        }," + 
				"                        \"BDValidationDate\": \"2016-01-01\"" + 
				"                     }" + 
				"                  }," + 
				"                  \"Address\": {" + 
				"                     \"AddressTypeCode\": {" + 
				"                        \"@tc\": \"0\"," + 
				"                        \"$\": \"Mailing\"" + 
				"                     }," + 
				"                     \"Line1\": \"100 Main Street5\"," + 
				"                     \"Line2\": \"Phoenix\"," + 
				"                     \"Line3\": \"line3\"," + 
				"                     \"City\": \"Morris Plains\"," + 
				"                     \"AddressStateTC\": {" + 
				"                        \"@tc\": \"37\"," + 
				"                        \"$\": \"NY\"" + 
				"                     }," + 
				"                     \"Zip\": \"07950\"," + 
				"                     \"AddressCountryTC\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"USA\"" + 
				"                     }," + 
				"                     \"PrefAddr\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"true\"" + 
				"                     }," + 
				"                     \"SolicitationInd\": {" + 
				"                        \"@tc\": \"0\"," + 
				"                        \"$\": \"false\"" + 
				"                     }," + 
				"                     \"PostalDropCode\": []," + 
				"                     \"AddressValidInd\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"true\"" + 
				"                     }" + 
				"                  }," + 
				"                  \"Phone\": {" + 
				"                     \"PhoneTypeCode\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"Home\"" + 
				"                     }," + 
				"                     \"AreaCode\": \"555\"," + 
				"                     \"DialNumber\": \"1233332\"," + 
				"                     \"SolicitationInd\": {" + 
				"                        \"@tc\": \"0\"," + 
				"                        \"$\": \"false\"" + 
				"                     }" + 
				"                  }," + 
				"                  \"EMailAddress\": {" + 
				"                     \"EMailType\": {" + 
				"                        \"@tc\": \"5\"," + 
				"                        \"$\": \"Primary\"" + 
				"                     }," + 
				"                     \"AddrLine\": \"saurabh.kale@gmail.com\"," + 
				"                     \"SolicitationInd\": {" + 
				"                        \"@tc\": \"1\"," + 
				"                        \"$\": \"true\"" + 
				"                     }" + 
				"                  }" + 
				"               }" + 
				"            ]," + 
				"            \"Relation\": [" + 
				"               {" + 
				"                  \"@OriginatingObjectID\": \"Holding_ProposedPolicy\"," + 
				"                  \"@RelatedObjectID\": \"Party_Agent\"," + 
				"                  \"@id\": \"R_Agent_to_Holding\"," + 
				"                  \"OriginatingObjectType\": {" + 
				"                     \"@tc\": \"4\"," + 
				"                     \"$\": \"Holding\"" + 
				"                  }," + 
				"                  \"RelatedObjectType\": {" + 
				"                     \"@tc\": \"6\"," + 
				"                     \"$\": \"Party\"" + 
				"                  }," + 
				"                  \"RelationRoleCode\": {" + 
				"                     \"@tc\": \"37\"," + 
				"                     \"$\": \"Agent of Record\"" + 
				"                  }" + 
				"               }," + 
				"               {" + 
				"                  \"@OriginatingObjectID\": \"Holding_ProposedPolicy\"," + 
				"                  \"@RelatedObjectID\": \"Party_PrimaryAnnuitant\"," + 
				"                  \"@id\": \"Party_Annuitant\"," + 
				"                  \"OriginatingObjectType\": {" + 
				"                     \"@tc\": \"4\"," + 
				"                     \"$\": \"Holding\"" + 
				"                  }," + 
				"                  \"RelatedObjectType\": {" + 
				"                     \"@tc\": \"6\"," + 
				"                     \"$\": \"Party\"" + 
				"                  }," + 
				"                  \"RelationRoleCode\": {" + 
				"                     \"@tc\": \"35\"," + 
				"                     \"$\": \"Annuitant\"" + 
				"                  }," + 
				"                  \"InterestPercent\": \"100\"" + 
				"               }," + 
				"               {" + 
				"                  \"@OriginatingObjectID\": \"Holding_ProposedPolicy\"," + 
				"                  \"@RelatedObjectID\": \"Party_PrimaryAnnuitant\"," + 
				"                  \"@id\": \"Party_Owner\"," + 
				"                  \"OriginatingObjectType\": {" + 
				"                     \"@tc\": \"4\"," + 
				"                     \"$\": \"Holding\"" + 
				"                  }," + 
				"                  \"RelatedObjectType\": {" + 
				"                     \"@tc\": \"6\"," + 
				"                     \"$\": \"Party\"" + 
				"                  }," + 
				"                  \"RelationRoleCode\": {" + 
				"                     \"@tc\": \"8\"," + 
				"                     \"$\": \"Owner\"" + 
				"                  }," + 
				"                  \"InterestPercent\": \"100\"" + 
				"               }," + 
				"               {" + 
				"                  \"@OriginatingObjectID\": \"Holding_ProposedPolicy\"," + 
				"                  \"@RelatedObjectID\": \"Party_Joint_Owner_Company\"," + 
				"                  \"@id\": \"Party_JOwner_Com\"," + 
				"                  \"OriginatingObjectType\": {" + 
				"                     \"@tc\": \"4\"," + 
				"                     \"$\": \"Holding\"" + 
				"                  }," + 
				"                  \"RelatedObjectType\": {" + 
				"                     \"@tc\": \"6\"," + 
				"                     \"$\": \"Party\"" + 
				"                  }," + 
				"                  \"RelationRoleCode\": {" + 
				"                     \"@tc\": \"184\"," + 
				"                     \"$\": \"Joint Owner\"" + 
				"                  }," + 
				"                  \"InterestPercent\": \"60\"" + 
				"               }," + 
				"               {" + 
				"                  \"@OriginatingObjectID\": \"Holding_ProposedPolicy\"," + 
				"                  \"@RelatedObjectID\": \"Party_Joint_Owner_Individual\"," + 
				"                  \"@id\": \"Party_JOwner_Ind\"," + 
				"                  \"OriginatingObjectType\": {" + 
				"                     \"@tc\": \"4\"," + 
				"                     \"$\": \"Holding\"" + 
				"                  }," + 
				"                  \"RelatedObjectType\": {" + 
				"                     \"@tc\": \"6\"," + 
				"                     \"$\": \"Party\"" + 
				"                  }," + 
				"                  \"RelationRoleCode\": {" + 
				"                     \"@tc\": \"184\"," + 
				"                     \"$\": \"Joint Owner\"" + 
				"                  }," + 
				"                  \"InterestPercent\": \"40\"" + 
				"               }" + 
				"            ]" + 
				"         }" + 
				"      }" + 
				"   }" + 
				"}";
	}
}
