
# ApplicationsubmitTXLifeRequestOLifEPolicyOLifEExtension

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subAcctID** | **String** |  |  [optional]
**initDepositAmt** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**draftDate** | **String** |  |  [optional]
**backupWithholdingIndicator** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEPolicyBackupWithholdingIndicator&gt;**](ApplicationsubmitTXLifeRequestOLifEPolicyBackupWithholdingIndicator.md) |  |  [optional]
**caseIGO** | **List&lt;String&gt;** |  |  [optional]
**eDeliveryOptOutOptionIndicator** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEPolicyBackupWithholdingIndicator&gt;**](ApplicationsubmitTXLifeRequestOLifEPolicyBackupWithholdingIndicator.md) |  |  [optional]
**bdValidationDate** | **List&lt;String&gt;** |  |  [optional]



