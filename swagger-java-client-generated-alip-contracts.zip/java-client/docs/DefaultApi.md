# DefaultApi

All URIs are relative to *http://alipmule.eastus.cloudapp.azure.com/alip-contracts*

Method | HTTP request | Description
------------- | ------------- | -------------
[**contractsIdBillingGet**](DefaultApi.md#contractsIdBillingGet) | **GET** /contracts/{id}/billing | 
[**contractsIdBillingPost**](DefaultApi.md#contractsIdBillingPost) | **POST** /contracts/{id}/billing | 
[**contractsIdGet**](DefaultApi.md#contractsIdGet) | **GET** /contracts/{id} | 
[**contractsVerIdGet**](DefaultApi.md#contractsVerIdGet) | **GET** /contracts/{ver}/{id} | 
[**customersIdContractsGet**](DefaultApi.md#customersIdContractsGet) | **GET** /customers/{id}/contracts | 


<a name="contractsIdBillingGet"></a>
# **contractsIdBillingGet**
> Map&lt;String, ERRORUNKNOWN&gt; contractsIdBillingGet(id)



get contract billing information from ALIP

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String id = "id_example"; // String | Contract Number
try {
    Map<String, ERRORUNKNOWN> result = apiInstance.contractsIdBillingGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#contractsIdBillingGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Contract Number |

### Return type

[**Map&lt;String, ERRORUNKNOWN&gt;**](ERRORUNKNOWN.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="contractsIdBillingPost"></a>
# **contractsIdBillingPost**
> ERRORUNKNOWN contractsIdBillingPost(id, generated)



billing change information

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String id = "id_example"; // String | Contract Number
ERRORUNKNOWN generated = new ERRORUNKNOWN(); // ERRORUNKNOWN | 
try {
    ERRORUNKNOWN result = apiInstance.contractsIdBillingPost(id, generated);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#contractsIdBillingPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Contract Number |
 **generated** | [**ERRORUNKNOWN**](ERRORUNKNOWN.md)|  | [optional]

### Return type

[**ERRORUNKNOWN**](ERRORUNKNOWN.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="contractsIdGet"></a>
# **contractsIdGet**
> Map&lt;String, ERRORUNKNOWN&gt; contractsIdGet(id)



get contract summary from ALIP

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String id = "id_example"; // String | Contract Number
try {
    Map<String, ERRORUNKNOWN> result = apiInstance.contractsIdGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#contractsIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Contract Number |

### Return type

[**Map&lt;String, ERRORUNKNOWN&gt;**](ERRORUNKNOWN.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="contractsVerIdGet"></a>
# **contractsVerIdGet**
> Map&lt;String, ERRORUNKNOWN&gt; contractsVerIdGet(ver, id)



get contract summary version API

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String ver = "ver_example"; // String | Version
String id = "id_example"; // String | Contract Number
try {
    Map<String, ERRORUNKNOWN> result = apiInstance.contractsVerIdGet(ver, id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#contractsVerIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ver** | **String**| Version |
 **id** | **String**| Contract Number |

### Return type

[**Map&lt;String, ERRORUNKNOWN&gt;**](ERRORUNKNOWN.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="customersIdContractsGet"></a>
# **customersIdContractsGet**
> ERRORUNKNOWN customersIdContractsGet(id)



Get customer contracts from ALIP

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String id = "id_example"; // String | Customer ID
try {
    ERRORUNKNOWN result = apiInstance.customersIdContractsGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#customersIdContractsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Customer ID |

### Return type

[**ERRORUNKNOWN**](ERRORUNKNOWN.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

