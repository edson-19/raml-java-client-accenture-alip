
# ApplicationsubmitTXLifeRequestTransType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tc** | [**TcEnum**](#TcEnum) |  |  [optional]
**value** | **String** |  |  [optional]


<a name="TcEnum"></a>
## Enum: TcEnum
Name | Value
---- | -----
_103 | &quot;103&quot;



