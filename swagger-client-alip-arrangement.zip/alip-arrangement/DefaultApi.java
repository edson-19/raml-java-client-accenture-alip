package com.accenture.alip.swagger.api;

import com.accenture.alip.swagger.invoker.ApiException;
import com.accenture.alip.swagger.invoker.ApiClient;
import com.accenture.alip.swagger.invoker.Configuration;
import com.accenture.alip.swagger.invoker.Pair;

import javax.ws.rs.core.GenericType;

import com.accenture.alip.swagger.model.Generated;
import com.accenture.alip.swagger.model.Generated1;
import com.accenture.alip.swagger.model.Generated2;
import com.accenture.alip.swagger.model.Generated3;
import com.accenture.alip.swagger.model.Generated4;
import com.accenture.alip.swagger.model.InlineResponse200;
import com.accenture.alip.swagger.model.InlineResponse2001;
import com.accenture.alip.swagger.model.InlineResponse2002;
import com.accenture.alip.swagger.model.InlineResponse2003;
import com.accenture.alip.swagger.model.InlineResponse2004;
import com.accenture.alip.swagger.model.InlineResponse2005;
import com.accenture.alip.swagger.model.InlineResponse400;
import com.accenture.alip.swagger.model.InlineResponse4001;
import com.accenture.alip.swagger.model.InlineResponse4002;
import com.accenture.alip.swagger.model.InlineResponse4003;
import com.accenture.alip.swagger.model.InlineResponse4004;
import com.accenture.alip.swagger.model.InlineResponse4005;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2019-05-16T06:15:17.315-04:00")
public class DefaultApi {
  private ApiClient apiClient;

  public DefaultApi() {
    this(Configuration.getDefaultApiClient());
  }

  public DefaultApi(ApiClient apiClient) {
    this.apiClient = apiClient;
  }

  public ApiClient getApiClient() {
    return apiClient;
  }

  public void setApiClient(ApiClient apiClient) {
    this.apiClient = apiClient;
  }

  /**
   * 
   * Add/Update Arrangements API Auto Rebalance
   * @param id Contract Number (required)
   * @param clientId  (required)
   * @param clientSecret  (required)
   * @param generated  (optional)
   * @return InlineResponse2004
   * @throws ApiException if fails to make API call
   */
  public InlineResponse2004 contractsIdArrangementsArPost(String id, String clientId, String clientSecret, Generated3 generated) throws ApiException {
    Object localVarPostBody = generated;
    
    // verify the required parameter 'id' is set
    if (id == null) {
      throw new ApiException(400, "Missing the required parameter 'id' when calling contractsIdArrangementsArPost");
    }
    
    // verify the required parameter 'clientId' is set
    if (clientId == null) {
      throw new ApiException(400, "Missing the required parameter 'clientId' when calling contractsIdArrangementsArPost");
    }
    
    // verify the required parameter 'clientSecret' is set
    if (clientSecret == null) {
      throw new ApiException(400, "Missing the required parameter 'clientSecret' when calling contractsIdArrangementsArPost");
    }
    
    // create path and map variables
    String localVarPath = "/contracts/{id}/arrangements".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

    // query params
    List<Pair> localVarQueryParams = new ArrayList<Pair>();
    Map<String, String> localVarHeaderParams = new HashMap<String, String>();
    Map<String, Object> localVarFormParams = new HashMap<String, Object>();


    if (clientId != null)
      localVarHeaderParams.put("client_id", apiClient.parameterToString(clientId));
if (clientSecret != null)
      localVarHeaderParams.put("client_secret", apiClient.parameterToString(clientSecret));

    
    final String[] localVarAccepts = {
      
    };
    final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

    final String[] localVarContentTypes = {
      
    };
    final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

    String[] localVarAuthNames = new String[] {  };

    GenericType<InlineResponse2004> localVarReturnType = new GenericType<InlineResponse2004>() {};
    return apiClient.invokeAPI(localVarPath, "POST", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
      }
  /**
   * 
   * Delete Arrangements API
   * @param id Contract Number (required)
   * @param arrangementSysKey Arrangement Sys Key (required)
   * @param clientId  (required)
   * @param clientSecret  (required)
   * @param generated  (optional)
   * @return InlineResponse2005
   * @throws ApiException if fails to make API call
   */
  public InlineResponse2005 contractsIdArrangementsArrangementSysKeyDelete(String id, String arrangementSysKey, String clientId, String clientSecret, Generated4 generated) throws ApiException {
    Object localVarPostBody = generated;
    
    // verify the required parameter 'id' is set
    if (id == null) {
      throw new ApiException(400, "Missing the required parameter 'id' when calling contractsIdArrangementsArrangementSysKeyDelete");
    }
    
    // verify the required parameter 'arrangementSysKey' is set
    if (arrangementSysKey == null) {
      throw new ApiException(400, "Missing the required parameter 'arrangementSysKey' when calling contractsIdArrangementsArrangementSysKeyDelete");
    }
    
    // verify the required parameter 'clientId' is set
    if (clientId == null) {
      throw new ApiException(400, "Missing the required parameter 'clientId' when calling contractsIdArrangementsArrangementSysKeyDelete");
    }
    
    // verify the required parameter 'clientSecret' is set
    if (clientSecret == null) {
      throw new ApiException(400, "Missing the required parameter 'clientSecret' when calling contractsIdArrangementsArrangementSysKeyDelete");
    }
    
    // create path and map variables
    String localVarPath = "/contracts/{id}/arrangements/{arrangementSysKey}".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()))
      .replaceAll("\\{" + "arrangementSysKey" + "\\}", apiClient.escapeString(arrangementSysKey.toString()));

    // query params
    List<Pair> localVarQueryParams = new ArrayList<Pair>();
    Map<String, String> localVarHeaderParams = new HashMap<String, String>();
    Map<String, Object> localVarFormParams = new HashMap<String, Object>();


    if (clientId != null)
      localVarHeaderParams.put("client_id", apiClient.parameterToString(clientId));
if (clientSecret != null)
      localVarHeaderParams.put("client_secret", apiClient.parameterToString(clientSecret));

    
    final String[] localVarAccepts = {
      
    };
    final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

    final String[] localVarContentTypes = {
      
    };
    final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

    String[] localVarAuthNames = new String[] {  };

    GenericType<InlineResponse2005> localVarReturnType = new GenericType<InlineResponse2005>() {};
    return apiClient.invokeAPI(localVarPath, "DELETE", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
      }
  /**
   * 
   * Add/Update Arrangements API Dollar Cost Average
   * @param id Contract Number (required)
   * @param clientId  (required)
   * @param clientSecret  (required)
   * @param generated  (optional)
   * @return InlineResponse2002
   * @throws ApiException if fails to make API call
   */
  public InlineResponse2002 contractsIdArrangementsDcaPost(String id, String clientId, String clientSecret, Generated1 generated) throws ApiException {
    Object localVarPostBody = generated;
    
    // verify the required parameter 'id' is set
    if (id == null) {
      throw new ApiException(400, "Missing the required parameter 'id' when calling contractsIdArrangementsDcaPost");
    }
    
    // verify the required parameter 'clientId' is set
    if (clientId == null) {
      throw new ApiException(400, "Missing the required parameter 'clientId' when calling contractsIdArrangementsDcaPost");
    }
    
    // verify the required parameter 'clientSecret' is set
    if (clientSecret == null) {
      throw new ApiException(400, "Missing the required parameter 'clientSecret' when calling contractsIdArrangementsDcaPost");
    }
    
    // create path and map variables
    String localVarPath = "/contracts/{id}/arrangements".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

    // query params
    List<Pair> localVarQueryParams = new ArrayList<Pair>();
    Map<String, String> localVarHeaderParams = new HashMap<String, String>();
    Map<String, Object> localVarFormParams = new HashMap<String, Object>();


    if (clientId != null)
      localVarHeaderParams.put("client_id", apiClient.parameterToString(clientId));
if (clientSecret != null)
      localVarHeaderParams.put("client_secret", apiClient.parameterToString(clientSecret));

    
    final String[] localVarAccepts = {
      
    };
    final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

    final String[] localVarContentTypes = {
      
    };
    final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

    String[] localVarAuthNames = new String[] {  };

    GenericType<InlineResponse2002> localVarReturnType = new GenericType<InlineResponse2002>() {};
    return apiClient.invokeAPI(localVarPath, "POST", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
      }
  /**
   * 
   * Add/Update Arrangements API EFT
   * @param id Contract Number (required)
   * @param clientId  (required)
   * @param clientSecret  (required)
   * @param generated  (optional)
   * @return InlineResponse2003
   * @throws ApiException if fails to make API call
   */
  public InlineResponse2003 contractsIdArrangementsEftPost(String id, String clientId, String clientSecret, Generated2 generated) throws ApiException {
    Object localVarPostBody = generated;
    
    // verify the required parameter 'id' is set
    if (id == null) {
      throw new ApiException(400, "Missing the required parameter 'id' when calling contractsIdArrangementsEftPost");
    }
    
    // verify the required parameter 'clientId' is set
    if (clientId == null) {
      throw new ApiException(400, "Missing the required parameter 'clientId' when calling contractsIdArrangementsEftPost");
    }
    
    // verify the required parameter 'clientSecret' is set
    if (clientSecret == null) {
      throw new ApiException(400, "Missing the required parameter 'clientSecret' when calling contractsIdArrangementsEftPost");
    }
    
    // create path and map variables
    String localVarPath = "/contracts/{id}/arrangements".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

    // query params
    List<Pair> localVarQueryParams = new ArrayList<Pair>();
    Map<String, String> localVarHeaderParams = new HashMap<String, String>();
    Map<String, Object> localVarFormParams = new HashMap<String, Object>();


    if (clientId != null)
      localVarHeaderParams.put("client_id", apiClient.parameterToString(clientId));
if (clientSecret != null)
      localVarHeaderParams.put("client_secret", apiClient.parameterToString(clientSecret));

    
    final String[] localVarAccepts = {
      
    };
    final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

    final String[] localVarContentTypes = {
      
    };
    final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

    String[] localVarAuthNames = new String[] {  };

    GenericType<InlineResponse2003> localVarReturnType = new GenericType<InlineResponse2003>() {};
    return apiClient.invokeAPI(localVarPath, "POST", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
      }
  /**
   * 
   * Get Available Arrangements for Contract API
   * @param id Contract Number (required)
   * @param clientId  (required)
   * @param clientSecret  (required)
   * @return InlineResponse200
   * @throws ApiException if fails to make API call
   */
  public InlineResponse200 contractsIdArrangementsGet(String id, String clientId, String clientSecret) throws ApiException {
    Object localVarPostBody = null;
    
    // verify the required parameter 'id' is set
    if (id == null) {
      throw new ApiException(400, "Missing the required parameter 'id' when calling contractsIdArrangementsGet");
    }
    
    // verify the required parameter 'clientId' is set
    if (clientId == null) {
      throw new ApiException(400, "Missing the required parameter 'clientId' when calling contractsIdArrangementsGet");
    }
    
    // verify the required parameter 'clientSecret' is set
    if (clientSecret == null) {
      throw new ApiException(400, "Missing the required parameter 'clientSecret' when calling contractsIdArrangementsGet");
    }
    
    // create path and map variables
    String localVarPath = "/contracts/{id}/arrangements".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

    // query params
    List<Pair> localVarQueryParams = new ArrayList<Pair>();
    Map<String, String> localVarHeaderParams = new HashMap<String, String>();
    Map<String, Object> localVarFormParams = new HashMap<String, Object>();


    if (clientId != null)
      localVarHeaderParams.put("client_id", apiClient.parameterToString(clientId));
if (clientSecret != null)
      localVarHeaderParams.put("client_secret", apiClient.parameterToString(clientSecret));

    
    final String[] localVarAccepts = {
      
    };
    final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

    final String[] localVarContentTypes = {
      
    };
    final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

    String[] localVarAuthNames = new String[] {  };

    GenericType<InlineResponse200> localVarReturnType = new GenericType<InlineResponse200>() {};
    return apiClient.invokeAPI(localVarPath, "GET", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
      }
  /**
   * 
   * Add/Update Arrangements API Systematic Withdrawal
   * @param id Contract Number (required)
   * @param clientId  (required)
   * @param clientSecret  (required)
   * @param generated  (optional)
   * @return InlineResponse2001
   * @throws ApiException if fails to make API call
   */
  public InlineResponse2001 contractsIdArrangementsPost(String id, String clientId, String clientSecret, Generated generated) throws ApiException {
    Object localVarPostBody = generated;
    
    // verify the required parameter 'id' is set
    if (id == null) {
      throw new ApiException(400, "Missing the required parameter 'id' when calling contractsIdArrangementsPost");
    }
    
    // verify the required parameter 'clientId' is set
    if (clientId == null) {
      throw new ApiException(400, "Missing the required parameter 'clientId' when calling contractsIdArrangementsPost");
    }
    
    // verify the required parameter 'clientSecret' is set
    if (clientSecret == null) {
      throw new ApiException(400, "Missing the required parameter 'clientSecret' when calling contractsIdArrangementsPost");
    }
    
    // create path and map variables
    String localVarPath = "/contracts/{id}/arrangements".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

    // query params
    List<Pair> localVarQueryParams = new ArrayList<Pair>();
    Map<String, String> localVarHeaderParams = new HashMap<String, String>();
    Map<String, Object> localVarFormParams = new HashMap<String, Object>();


    if (clientId != null)
      localVarHeaderParams.put("client_id", apiClient.parameterToString(clientId));
if (clientSecret != null)
      localVarHeaderParams.put("client_secret", apiClient.parameterToString(clientSecret));

    
    final String[] localVarAccepts = {
      
    };
    final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

    final String[] localVarContentTypes = {
      
    };
    final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

    String[] localVarAuthNames = new String[] {  };

    GenericType<InlineResponse2001> localVarReturnType = new GenericType<InlineResponse2001>() {};
    return apiClient.invokeAPI(localVarPath, "POST", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
      }
}
