
# ApplicationsubmitTXLifeRequestOLifEPolicyAnnuityProductFeatureProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**featureCode** | **String** |  | 
**name** | **String** |  |  [optional]
**featureOptProduct** | [**ApplicationsubmitTXLifeRequestOLifEPolicyAnnuityProductFeatureProductFeatureOptProduct**](ApplicationsubmitTXLifeRequestOLifEPolicyAnnuityProductFeatureProductFeatureOptProduct.md) |  | 



