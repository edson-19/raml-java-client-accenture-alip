import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.mule.example.api.AlipcustomerClient;
import org.mule.example.responses.AlipcustomerResponse;
import org.mule.example.exceptions.AlipcustomerException;
import org.mule.example.resource.customers.id.phone.type.model.TypeDELETEBody;
import org.mule.example.resource.customers.id.phone.type.model.TypeDELETEResponseBody;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import org.glassfish.jersey.client.ClientProperties;

import com.fasterxml.jackson.databind.ObjectMapper;

public class ClientExample {
    @SuppressWarnings("static-access")
	public static void main(String[] args) {
        try {
        	
        	final AlipcustomerResponse<TypeDELETEResponseBody> result = new AlipcustomerClient() {
                 @Override
                 protected Client getClient() {
                     final Client client = ClientBuilder.newClient();
                     client.property(ClientProperties.CONNECT_TIMEOUT, 60000);
                     client.property(ClientProperties.READ_TIMEOUT, 60000);
                     //client.property(ClientProperties.REQUEST_ENTITY_PROCESSING, body());
                     client.property(ClientProperties.SUPPRESS_HTTP_COMPLIANCE_VALIDATION, true);
                     return client;
                 }
         	}.create("http://10.6.44.198:8080/relrt12wsgateway/api/ext-portal")
        			.customers.id("4460").phone.type("home").delete(body());
            
        	/**
            final AlipcustomerResponse<TypeDELETEResponseBody> result =
            //AlipcustomerClient.create("http://vm-int2.navisys.com/intmockwsgateway/api/ext-portal")
            AlipcustomerClient.create("http://10.6.44.198:8080/relrt12wsgateway/api/ext-portal")
            	.customers.id("4460").phone.type("home").delete(body());
			**/
            System.out.println ("TransRefGUID: " + result.getBody().getTXLife().getTXLifeResponse().getTransRefGUID());
            System.out.println ("TransExeDate: " + result.getBody().getTXLife().getTXLifeResponse().getTransExeDate());
            System.out.println ("TransExeTime: " + result.getBody().getTXLife().getTXLifeResponse().getTransExeTime());
            System.out.println ("ResultCode: " + result.getBody().getTXLife().getTXLifeResponse().getTransResult().getResultCode().getTc());

        } catch ( AlipcustomerException e ) {
        	System.err.println("Exception: " + e.getMessage());
            System.err.println("ERROR: " + e.getStatusCode() + " " + e.getReason());
            System.err.println("ERROR: " + e.getResponse().toString());
            e.printStackTrace();
        }
    }
    
    public static TypeDELETEBody body() {
    	TypeDELETEBody body;
    	String json = input(); 
        ObjectMapper mapper = new ObjectMapper();
        try {
        	body = mapper.readValue(json, TypeDELETEBody.class);
            
        	System.out.println("REQUEST: " + body.toString());
            System.out.println("UserLoginName: " + body.getTXLife().getUserAuthRequest().getUserLoginName());
            System.out.println("getTransType: " + body.getTXLife().getTXLifeRequest().getTransType().getTc());
            System.out.println("getTransSubType: " + body.getTXLife().getTXLifeRequest().getTransSubType().getTc());
            System.out.println("TransExeDate: " + body.getTXLife().getTXLifeRequest().getTransExeDate());
            
    		return body;
        } catch (IOException e) {
            e.printStackTrace();
        }
		return null;
    	
    }
    
    public static String input(){
      String input = null;
      StringBuilder builder = new StringBuilder();
      FileReader fr = null;
      BufferedReader br = null;
      try {
    	fr = new FileReader("src\\test\\java\\customerPhoneDeleteRequest.json");
    	br = new BufferedReader(fr);
    	String sCurrentLine;
		while ((sCurrentLine = br.readLine()) != null) {
			//System.out.println(sCurrentLine);
			builder.append(sCurrentLine);
		}
    	fr.close();
    	br.close();
      } catch (IOException e) {
    	  e.printStackTrace();
      } 
      //System.out.println("input: " + input);
      input = builder.toString();
      return input;
    }
    
}
