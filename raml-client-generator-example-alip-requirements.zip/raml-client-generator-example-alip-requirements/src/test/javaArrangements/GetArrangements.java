//import javax.ws.rs.client.Client;
//import javax.ws.rs.client.ClientBuilder;
//import org.glassfish.jersey.client.ClientProperties;
import org.mule.example.api.AliparrangementsClient;
import org.mule.example.exceptions.AliparrangementsException;
import org.mule.example.resource.contracts.id.arrangements.model.ArrangementsGETResponseBody;
import org.mule.example.responses.AliparrangementsResponse;


public class GetArrangements {

    public static void main(String[] args) {
        try {
        	/*
        	final AliparrangementsResponse<ArrangementsGETResponseBody> result = new AliparrangementsClient() {
                @Override
                protected Client getClient() {
                    final Client client = ClientBuilder.newClient();
                    client.property(ClientProperties.CONNECT_TIMEOUT, 60000);
                    client.property(ClientProperties.READ_TIMEOUT, 60000);
                    return client;
                }
            }.contracts.id("83914").arrangements.get();
            */
			
			 final AliparrangementsResponse<ArrangementsGETResponseBody> result = 
					//AliparrangementsClient.create("http://10.6.44.198:8080/relrt12wsgateway/api/ext-portal")
					AliparrangementsClient.create()
            		.contracts.id("83914").arrangements.get();
            
            
            System.out.println ("TransRefGUID: " + result.getBody().getTXLife().getTXLifeResponse().getTransRefGUID());
            System.out.println ("TransExeDate: " + result.getBody().getTXLife().getTXLifeResponse().getTransExeDate());
            System.out.println ("TransExeTime: " + result.getBody().getTXLife().getTXLifeResponse().getTransExeTime());
            System.out.println ("ResultCode: " + result.getBody().getTXLife().getTXLifeResponse().getTransResult().getResultCode().get$());
			
            //System.out.println ("TransRefGUID: " + result.getBody());
        } catch ( AliparrangementsException e ) {
            System.err.println("ERROR: " + e.getStatusCode() + " " + e.getReason());
            System.err.println("ERROR: " + e.getResponse().toString());
        }
    }
    
}

