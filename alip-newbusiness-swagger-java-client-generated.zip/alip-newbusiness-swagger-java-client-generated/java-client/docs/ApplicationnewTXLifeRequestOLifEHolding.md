
# ApplicationnewTXLifeRequestOLifEHolding

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**holdingTypeCode** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  | 
**policy** | [**ApplicationnewTXLifeRequestOLifEPolicy**](ApplicationnewTXLifeRequestOLifEPolicy.md) |  |  [optional]
**investment** | [**ApplicationsubmitTXLifeRequestOLifEInvestment**](ApplicationsubmitTXLifeRequestOLifEInvestment.md) |  |  [optional]
**arrangement** | [**List&lt;ApplicationnewTXLifeRequestOLifEArrangement&gt;**](ApplicationnewTXLifeRequestOLifEArrangement.md) |  |  [optional]
**banking** | [**ApplicationnewTXLifeRequestOLifEBanking**](ApplicationnewTXLifeRequestOLifEBanking.md) |  |  [optional]



