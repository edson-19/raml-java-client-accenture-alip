
# ApplicationsubmitTXLifeRequestOLifEPolicyLifeLifeUSA

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**defLifeInsMethod** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**meCInd** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]



