
# ApplicationsubmitTXLifeRequestOLifEPolicy

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**carrierPartyID** | **String** |  |  [optional]
**productType** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**productCode** | **String** |  |  [optional]
**polNumber** | **String** |  |  [optional]
**carrierCode** | **String** |  |  [optional]
**issueDate** | **String** |  |  [optional]
**replacementType** | [**ApplicationsubmitTXLifeRequestOLifEPolicyReplacementType**](ApplicationsubmitTXLifeRequestOLifEPolicyReplacementType.md) |  |  [optional]
**moneyTransferType** | [**ApplicationsubmitTXLifeRequestOLifEPolicyMoneyTransferType**](ApplicationsubmitTXLifeRequestOLifEPolicyMoneyTransferType.md) |  |  [optional]
**planName** | **String** |  |  [optional]
**policyStatus** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**jurisdiction** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**effDate** | **String** |  |  [optional]
**minPremiumInitialAmt** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**paymentMethod** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**paymentMode** | [**ApplicationsubmitTXLifeRequestOLifEPolicyPaymentMode**](ApplicationsubmitTXLifeRequestOLifEPolicyPaymentMode.md) |  |  [optional]
**paymentAmt** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**paymentDraftDay** | **String** |  |  [optional]
**life** | [**ApplicationsubmitTXLifeRequestOLifEPolicyLife**](ApplicationsubmitTXLifeRequestOLifEPolicyLife.md) |  |  [optional]
**annuity** | [**ApplicationsubmitTXLifeRequestOLifEPolicyAnnuity**](ApplicationsubmitTXLifeRequestOLifEPolicyAnnuity.md) |  |  [optional]
**annuityProduct** | [**ApplicationsubmitTXLifeRequestOLifEPolicyAnnuityProduct**](ApplicationsubmitTXLifeRequestOLifEPolicyAnnuityProduct.md) |  |  [optional]
**applicationInfo** | [**ApplicationsubmitTXLifeRequestOLifEPolicyApplicationInfo**](ApplicationsubmitTXLifeRequestOLifEPolicyApplicationInfo.md) |  |  [optional]
**olifEExtension** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEPolicyOLifEExtension&gt;**](ApplicationsubmitTXLifeRequestOLifEPolicyOLifEExtension.md) |  |  [optional]



