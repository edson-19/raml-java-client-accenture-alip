
# ApplicationsubmitTXLifeRequestOLifEPayrollDeduction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**payrollDeductionAmt** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



