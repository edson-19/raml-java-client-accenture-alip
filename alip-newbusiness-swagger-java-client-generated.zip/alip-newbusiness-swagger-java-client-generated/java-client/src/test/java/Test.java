import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
//import java.util.ArrayList;
//import java.util.List;
//import org.w3c.dom.ls.LSException;
import java.util.Map;

import io.swagger.client.ApiException;
import io.swagger.client.api.DefaultApi;
import io.swagger.client.model.*;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Test {

	public static void main(String[] args) throws IOException {

		DefaultApi apiInstance = new DefaultApi();

		String clientId = "clientId_example"; // String | 
		String clientSecret = "clientSecret_example"; // String | 
		Generated body = new Generated();
		
        ObjectMapper mapper = new ObjectMapper();

		try {
	    	String json = input(); 
			body = mapper.readValue(json, Generated.class);
			apiInstance.getApiClient().setReadTimeout(600000);
			Map<String, Object> result = apiInstance.applicationSubmitPost(clientId, clientSecret, body);
			
		    //System.out.println(result.getClass()); // class com.google.gson.internal.LinkedTreeMap
		    System.out.println(result);
		    //System.out.println("TXLife: " +result.get("TXLife"));
		    result = (Map<String, Object>) result.get("TXLife");
		    result = (Map<String, Object>) result.get("TXLifeResponse");
		    System.out.println("TXLife.TXLifeResponse.TransRefGUID: " + result.get("TransRefGUID"));

		} catch (ApiException e) {
		    System.err.println("Exception: " + e.getMessage());
            System.err.println("ERROR: " + e.getCode() + " " + e.getCause());
            System.err.println("ERROR: " + e.getResponseBody().toString());
		    e.printStackTrace();
		}

	}
	
    public static String input(){
        String input = null;
        StringBuilder builder = new StringBuilder();
        FileReader fr = null;
        BufferedReader br = null;
        try {
      	fr = new FileReader("src\\test\\java\\nb_submit_req.json");
      	br = new BufferedReader(fr);
      	String sCurrentLine;
  		while ((sCurrentLine = br.readLine()) != null) {
  			//System.out.println(sCurrentLine);
  			builder.append(sCurrentLine);
  		}
      	fr.close();
      	br.close();
        } catch (IOException e) {
      	  e.printStackTrace();
        } 
        //System.out.println("input: " + input);
        input = builder.toString();
        return input;
      }

/**
	public static void main(String[] args) throws IOException {

		DefaultApi apiInstance = new DefaultApi();

		String clientId = "clientId_example"; // String | 
		String clientSecret = "clientSecret_example"; // String | 
		String id = "131"; // String | Customer ID
		String startDate = "20180101";
		String endDate = "20181231";
		/--
		Generated request = new Generated();
		new ApplicationsubmitTXLifeRequest();
		request.setTransRefGUID("44a71996-31b4-7cd9-3a6e-aa87745aac01");
		request.setTransExeDate("2019-02-01");
		request.setTransExeTime("19:27:14");
		request.setTransType(new ApplicationsubmitTXLifeRequestTransType());
		request.setTransSubType(new ApplicationsubmitTXLifeRequestTransSubType());
		request.setOlifE(new ApplicationsubmitTXLifeRequestOLifE());
		--/
		try {
			Map<String, Object> result = apiInstance.
			  agentsIdDashboardApplicationsStartDateEndDateGet(clientId, clientSecret, id, startDate, endDate);
		    System.out.println(result.getClass()); // class com.google.gson.internal.LinkedTreeMap
		    System.out.println(result);
		    System.out.println(result.get("TXLife"));
		    //.TXLife.TXLifeResponse.TransRefGUID);
		    //result = apiInstance.applicationSubmitPost(clientId, clientSecret, request);
		    //System.out.println(result);
		} catch (ApiException e) {
		    System.err.println("Exception when calling DefaultApi#customersIdAccountsGet");
		    e.printStackTrace();
		}

	}
**/
	
}
