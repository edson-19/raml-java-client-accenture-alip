
# ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tc** | **String** |  |  [optional]
**value** | **String** |  |  [optional]



