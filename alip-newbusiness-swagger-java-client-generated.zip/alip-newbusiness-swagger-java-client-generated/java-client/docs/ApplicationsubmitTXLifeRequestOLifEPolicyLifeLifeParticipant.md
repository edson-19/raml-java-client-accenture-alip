
# ApplicationsubmitTXLifeRequestOLifEPolicyLifeLifeParticipant

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lifeParticipantRoleCode** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**tobaccoPremiumBasis** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**underwritingClass** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]



