
# ApplicationsubmitTXLifeRequestOLifEBanking

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bankAcctType** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  | 
**accountNumber** | **String** |  | 
**routingNum** | **String** |  |  [optional]
**acctHolderName** | **String** |  | 
**bankName** | **String** |  |  [optional]
**bankingDescriptor** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]



