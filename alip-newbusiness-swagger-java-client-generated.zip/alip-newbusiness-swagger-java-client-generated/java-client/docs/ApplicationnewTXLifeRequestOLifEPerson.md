
# ApplicationnewTXLifeRequestOLifEPerson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**personKey** | [**ApplicationsubmitTXLifeRequestOLifEPersonPersonKey**](ApplicationsubmitTXLifeRequestOLifEPersonPersonKey.md) |  |  [optional]
**personSysKey** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEPersonPersonKey&gt;**](ApplicationsubmitTXLifeRequestOLifEPersonPersonKey.md) |  |  [optional]
**firstName** | **String** |  | 
**middleName** | **String** |  |  [optional]
**lastName** | **String** |  | 
**prefix** | **String** |  |  [optional]
**title** | **String** |  |  [optional]
**marStat** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**gender** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**birthDate** | **String** |  |  [optional]
**citizenship** | [**ApplicationnewTXLifeRequestOLifEResidenceCountry**](ApplicationnewTXLifeRequestOLifEResidenceCountry.md) |  |  [optional]
**estGrossAnnualOtherIncome** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**nonResidentAlienInd** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**occupation** | **String** |  |  [optional]
**olifEExtension** | [**List&lt;ApplicationnewTXLifeRequestOLifESourceInfoOlifEExtension&gt;**](ApplicationnewTXLifeRequestOLifESourceInfoOlifEExtension.md) |  |  [optional]



