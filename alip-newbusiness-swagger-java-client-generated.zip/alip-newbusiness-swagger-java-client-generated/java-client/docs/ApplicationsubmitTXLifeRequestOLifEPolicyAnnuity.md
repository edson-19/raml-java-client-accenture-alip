
# ApplicationsubmitTXLifeRequestOLifEPolicyAnnuity

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**qualPlanType** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**initDepositDate** | **String** |  |  [optional]
**payout** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEPolicyAnnuityPayout&gt;**](ApplicationsubmitTXLifeRequestOLifEPolicyAnnuityPayout.md) |  |  [optional]



