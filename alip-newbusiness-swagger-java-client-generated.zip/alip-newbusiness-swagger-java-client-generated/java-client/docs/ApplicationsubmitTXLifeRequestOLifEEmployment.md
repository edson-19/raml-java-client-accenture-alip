
# ApplicationsubmitTXLifeRequestOLifEEmployment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**employmentKey** | [**ApplicationsubmitTXLifeRequestOLifEPersonPersonKey**](ApplicationsubmitTXLifeRequestOLifEPersonPersonKey.md) |  |  [optional]
**employmentSysKey** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEPersonPersonKey&gt;**](ApplicationsubmitTXLifeRequestOLifEPersonPersonKey.md) |  |  [optional]
**pay** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEPay&gt;**](ApplicationsubmitTXLifeRequestOLifEPay.md) |  |  [optional]
**employeeID** | **String** |  |  [optional]



