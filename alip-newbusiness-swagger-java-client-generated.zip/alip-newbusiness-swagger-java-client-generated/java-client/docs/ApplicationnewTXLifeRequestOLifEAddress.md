
# ApplicationnewTXLifeRequestOLifEAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**addressKey** | [**ApplicationsubmitTXLifeRequestOLifEPersonPersonKey**](ApplicationsubmitTXLifeRequestOLifEPersonPersonKey.md) |  |  [optional]
**addressSysKey** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEPersonPersonKey&gt;**](ApplicationsubmitTXLifeRequestOLifEPersonPersonKey.md) |  |  [optional]
**addressTypeCode** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  | 
**line1** | **String** |  |  [optional]
**line2** | **String** |  |  [optional]
**line3** | **String** |  |  [optional]
**city** | **String** |  |  [optional]
**zip** | **String** |  |  [optional]
**prefAddr** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**startDate** | **String** |  |  [optional]
**endDate** | **String** |  |  [optional]
**solicitationInd** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**postalDropCode** | **String** |  |  [optional]
**addressValidInd** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**addressStateTC** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**addressCountryTC** | [**ApplicationnewTXLifeRequestOLifEResidenceCountry**](ApplicationnewTXLifeRequestOLifEResidenceCountry.md) |  |  [optional]



