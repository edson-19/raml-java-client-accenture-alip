
# ApplicationsubmitTXLifeRequestOLifEPersonPersonKey

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**persist** | **String** |  |  [optional]
**systemCode** | **String** |  |  [optional]
**vendorCode** | **String** |  |  [optional]
**value** | **String** |  |  [optional]



