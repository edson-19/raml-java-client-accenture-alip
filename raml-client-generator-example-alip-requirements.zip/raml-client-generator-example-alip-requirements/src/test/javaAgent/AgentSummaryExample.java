
import org.mule.example.api.AlipagentClient;
import org.mule.example.exceptions.AlipagentException;
//import org.mule.example.resource.agents.id.summary.Summary;
import org.mule.example.resource.agents.id.summary.model.*;
import org.mule.example.responses.AlipagentResponse;

public class AgentSummaryExample {
    public static void main(String[] args) {
        try {
        	SummaryGETQueryParam queryParameters = new SummaryGETQueryParam("client_secret", "client_id");
			final AlipagentResponse<SummaryGETResponseBody> result = 
					AlipagentClient.create("http://10.6.44.198:8080/relrt12wsgateway/api/ext-portal")
            		.agents.id("rt5112").summary.get(queryParameters);
               		
            System.out.println ("TransRefGUID: " + result.getBody().getTXLife().getTXLifeResponse().getTransRefGUID());
            System.out.println ("TransExeDate: " + result.getBody().getTXLife().getTXLifeResponse().getTransExeDate());
            System.out.println ("TransExeTime: " + result.getBody().getTXLife().getTXLifeResponse().getTransExeTime());
            System.out.println ("ResultCode: " + result.getBody().getTXLife().getTXLifeResponse().getTransResult().getResultCode().getContent());

        } catch ( AlipagentException e ) {
        	System.err.println("Exception: " + e.getMessage());
            System.err.println("ERROR: " + e.getStatusCode() + " " + e.getReason());
            System.err.println("ERROR: " + e.getResponse().toString());
            e.printStackTrace();
            
        }
    }
    
}