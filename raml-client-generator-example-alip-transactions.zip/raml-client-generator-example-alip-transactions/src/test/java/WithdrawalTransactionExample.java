
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.mule.example.api.AliptransactionClient;
import org.mule.example.exceptions.AliptransactionException;
import org.mule.example.resource.contracts.id.transactions.model.*;
import org.mule.example.resource.contracts.id.transactions.model.TransactionsPOSTBody;
import org.mule.example.responses.AliptransactionResponse;

import com.fasterxml.jackson.databind.ObjectMapper;


public class WithdrawalTransactionExample {
    public static void main(String[] args) {
        try {
            final AliptransactionResponse<String> result = 
            		AliptransactionClient.create("http://10.6.44.198:8080/relrt12wsgateway/api/ext-portal")
                	.contracts.id("07675").transactions.post(body());
            
            System.out.println ("Response: " + result.getBody().toString());
            //System.out.println ("TransExeDate: " + result.getBody().getTXLife().getTXLifeResponse().getTransExeDate());
            //System.out.println ("TransExeTime: " + result.getBody().getTXLife().getTXLifeResponse().getTransExeTime());
            //System.out.println ("ResultCode: " + result.getBody().getTXLife().getTXLifeResponse().getTransResult().getResultCode().get$());
            
        } catch ( AliptransactionException e ) {
        	System.err.println("Exception: " + e.getMessage());
            System.err.println("ERROR: " + e.getStatusCode() + " " + e.getReason());
            System.err.println("ERROR: " + e.getResponse().toString());
            e.printStackTrace();
            
        }
    }
    
    public static TransactionsPOSTBody body() {
    	TransactionsPOSTBody body;
    	String json = input(); 
        ObjectMapper mapper = new ObjectMapper();
        try {
        	body = mapper.readValue(json, TransactionsPOSTBody.class);
            
        	System.out.println("REQUEST: " + body.toString());
            System.out.println("TransRefGUID: " + body.getTXLife().getTXLifeRequest().getTransRefGUID());
            System.out.println("PolNumber: " + body.getTXLife().getTXLifeRequest().getOLifE().getHolding().getPolicy().getPolNumber());
            
    		return body;
        } catch (IOException e) {
            e.printStackTrace();
        }
		return null;
    	
    }
    
    public static String input(){
      String input = null;
      StringBuilder builder = new StringBuilder();
      FileReader fr = null;
      BufferedReader br = null;
      try {
    	fr = new FileReader("src\\test\\java\\withdrawal_transaction_req.json");
    	br = new BufferedReader(fr);
    	String sCurrentLine;
		while ((sCurrentLine = br.readLine()) != null) {
			//System.out.println(sCurrentLine);
			builder.append(sCurrentLine);
		}
    	fr.close();
    	br.close();
      } catch (IOException e) {
    	  e.printStackTrace();
      } 
      //System.out.println("input: " + input);
      input = builder.toString();
      return input;
    }
    
}
