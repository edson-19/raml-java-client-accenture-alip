
# ApplicationsubmitTXLifeRequestOLifEEMailAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**addrLine** | **String** |  |  [optional]
**solicitationInd** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**emailAddressKey** | [**ApplicationsubmitTXLifeRequestOLifEPersonPersonKey**](ApplicationsubmitTXLifeRequestOLifEPersonPersonKey.md) |  |  [optional]
**emailAddressSysKey** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEPersonPersonKey&gt;**](ApplicationsubmitTXLifeRequestOLifEPersonPersonKey.md) |  |  [optional]
**emailType** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]



