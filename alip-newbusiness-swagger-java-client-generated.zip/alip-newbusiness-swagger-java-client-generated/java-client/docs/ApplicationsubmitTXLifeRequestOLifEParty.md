
# ApplicationsubmitTXLifeRequestOLifEParty

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**partyTypeCode** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**fullName** | **String** |  |  [optional]
**residenceCountry** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**person** | [**ApplicationsubmitTXLifeRequestOLifEPerson**](ApplicationsubmitTXLifeRequestOLifEPerson.md) |  |  [optional]
**organization** | [**ApplicationsubmitTXLifeRequestOLifEOrganization**](ApplicationsubmitTXLifeRequestOLifEOrganization.md) |  |  [optional]
**address** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEAddress&gt;**](ApplicationsubmitTXLifeRequestOLifEAddress.md) |  |  [optional]
**phone** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEPhone&gt;**](ApplicationsubmitTXLifeRequestOLifEPhone.md) |  |  [optional]
**producer** | [**ApplicationsubmitTXLifeRequestOLifEProducer**](ApplicationsubmitTXLifeRequestOLifEProducer.md) |  |  [optional]
**employment** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEEmployment&gt;**](ApplicationsubmitTXLifeRequestOLifEEmployment.md) |  |  [optional]
**govtID** | **Integer** |  |  [optional]
**govtIDTC** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**govtIDCertificationDate** | **String** |  |  [optional]
**emailAddress** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEEMailAddress&gt;**](ApplicationsubmitTXLifeRequestOLifEEMailAddress.md) |  |  [optional]
**olifEExtension** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEPolicyOLifEExtension&gt;**](ApplicationsubmitTXLifeRequestOLifEPolicyOLifEExtension.md) |  |  [optional]



