
# ApplicationnewTXLifeRequestOLifEPolicyAnnuity

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**qualPlanType** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**initDepositDate** | **String** |  |  [optional]
**payout** | [**List&lt;ApplicationnewTXLifeRequestOLifEPolicyAnnuityPayout&gt;**](ApplicationnewTXLifeRequestOLifEPolicyAnnuityPayout.md) |  |  [optional]



