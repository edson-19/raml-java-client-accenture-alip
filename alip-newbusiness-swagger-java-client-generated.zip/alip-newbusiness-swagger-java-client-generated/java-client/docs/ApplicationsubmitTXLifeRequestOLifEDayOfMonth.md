
# ApplicationsubmitTXLifeRequestOLifEDayOfMonth

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tc** | [**TcEnum**](#TcEnum) |  |  [optional]
**value** | **String** |  |  [optional]


<a name="TcEnum"></a>
## Enum: TcEnum
Name | Value
---- | -----
_1 | &quot;1&quot;
_2 | &quot;2&quot;



