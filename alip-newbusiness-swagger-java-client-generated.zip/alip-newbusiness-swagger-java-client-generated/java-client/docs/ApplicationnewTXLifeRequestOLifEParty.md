
# ApplicationnewTXLifeRequestOLifEParty

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**partyTypeCode** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**fullName** | **String** |  |  [optional]
**residenceCountry** | [**ApplicationnewTXLifeRequestOLifEResidenceCountry**](ApplicationnewTXLifeRequestOLifEResidenceCountry.md) |  |  [optional]
**person** | [**ApplicationnewTXLifeRequestOLifEPerson**](ApplicationnewTXLifeRequestOLifEPerson.md) |  |  [optional]
**organization** | [**ApplicationsubmitTXLifeRequestOLifEOrganization**](ApplicationsubmitTXLifeRequestOLifEOrganization.md) |  |  [optional]
**address** | [**List&lt;ApplicationnewTXLifeRequestOLifEAddress&gt;**](ApplicationnewTXLifeRequestOLifEAddress.md) |  |  [optional]
**phone** | [**List&lt;ApplicationnewTXLifeRequestOLifEPhone&gt;**](ApplicationnewTXLifeRequestOLifEPhone.md) |  |  [optional]
**producer** | [**ApplicationsubmitTXLifeRequestOLifEProducer**](ApplicationsubmitTXLifeRequestOLifEProducer.md) |  |  [optional]
**employment** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEEmployment&gt;**](ApplicationsubmitTXLifeRequestOLifEEmployment.md) |  |  [optional]
**govtID** | **Integer** |  |  [optional]
**govtIDTC** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**govtIDCertificationDate** | **String** |  |  [optional]
**emailAddress** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEEMailAddress&gt;**](ApplicationsubmitTXLifeRequestOLifEEMailAddress.md) |  |  [optional]
**olifEExtension** | [**List&lt;ApplicationnewTXLifeRequestOLifESourceInfoOlifEExtension&gt;**](ApplicationnewTXLifeRequestOLifESourceInfoOlifEExtension.md) |  |  [optional]



