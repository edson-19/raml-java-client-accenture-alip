
# ApplicationsubmitTXLifeRequestOLifEHolding

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**dataRep** | **String** |  |  [optional]
**holdingTypeCode** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  | 
**policy** | [**ApplicationsubmitTXLifeRequestOLifEPolicy**](ApplicationsubmitTXLifeRequestOLifEPolicy.md) |  |  [optional]
**investment** | [**ApplicationsubmitTXLifeRequestOLifEInvestment**](ApplicationsubmitTXLifeRequestOLifEInvestment.md) |  |  [optional]
**arrangement** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEArrangement&gt;**](ApplicationsubmitTXLifeRequestOLifEArrangement.md) |  |  [optional]
**banking** | [**ApplicationsubmitTXLifeRequestOLifEBanking**](ApplicationsubmitTXLifeRequestOLifEBanking.md) |  |  [optional]



