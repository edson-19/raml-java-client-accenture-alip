
# ApplicationsubmitTXLifeRequestOLifEArrType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tc** | [**TcEnum**](#TcEnum) |  |  [optional]
**value** | **String** |  |  [optional]


<a name="TcEnum"></a>
## Enum: TcEnum
Name | Value
---- | -----
_2 | &quot;2&quot;
_3 | &quot;3&quot;
_22 | &quot;22&quot;
_54 | &quot;54&quot;



