
# ApplicationsubmitTXLifeRequestOLifEPolicyApplicationInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**trackingID** | **String** |  |  [optional]
**applicationJurisdiction** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**signedDate** | **String** |  |  [optional]
**signatureInfo** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEPolicyApplicationInfoSignatureInfo&gt;**](ApplicationsubmitTXLifeRequestOLifEPolicyApplicationInfoSignatureInfo.md) |  |  [optional]
**hoAssignedAppNumber** | **String** |  |  [optional]
**hoReceiptDate** | **String** |  |  [optional]



