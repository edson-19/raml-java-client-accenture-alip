
# ApplicationsubmitTXLifeRequestOLifEPolicyBackupWithholdingIndicator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tc** | [**TcEnum**](#TcEnum) |  |  [optional]
**value** | **String** |  |  [optional]


<a name="TcEnum"></a>
## Enum: TcEnum
Name | Value
---- | -----
_0 | &quot;0&quot;
_1 | &quot;1&quot;



