
# ApplicationsubmitTXLifeRequestOLifEPolicyLife

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**coverage** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEPolicyLifeCoverage&gt;**](ApplicationsubmitTXLifeRequestOLifEPolicyLifeCoverage.md) |  |  [optional]
**lifeUSA** | [**ApplicationsubmitTXLifeRequestOLifEPolicyLifeLifeUSA**](ApplicationsubmitTXLifeRequestOLifEPolicyLifeLifeUSA.md) |  |  [optional]
**initDepositAmt** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**initialPremAmt** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**initCovAmt** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**faceAmt** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**cwAAmt** | [**BigDecimal**](BigDecimal.md) |  |  [optional]



