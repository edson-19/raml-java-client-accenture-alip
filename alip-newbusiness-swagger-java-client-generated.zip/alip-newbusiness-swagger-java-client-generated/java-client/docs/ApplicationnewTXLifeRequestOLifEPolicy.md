
# ApplicationnewTXLifeRequestOLifEPolicy

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**polNumber** | **String** |  |  [optional]
**productType** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**productCode** | **String** |  |  [optional]
**carrierCode** | **String** |  |  [optional]
**planName** | **String** |  |  [optional]
**policyStatus** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**jurisdiction** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**effDate** | **String** |  |  [optional]
**minPremiumInitialAmt** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**paymentMethod** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**paymentMode** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**paymentAmt** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**paymentDraftDay** | **String** |  |  [optional]
**life** | [**ApplicationsubmitTXLifeRequestOLifEPolicyLife**](ApplicationsubmitTXLifeRequestOLifEPolicyLife.md) |  |  [optional]
**annuity** | [**ApplicationnewTXLifeRequestOLifEPolicyAnnuity**](ApplicationnewTXLifeRequestOLifEPolicyAnnuity.md) |  |  [optional]
**applicationInfo** | [**ApplicationnewTXLifeRequestOLifEPolicyApplicationInfo**](ApplicationnewTXLifeRequestOLifEPolicyApplicationInfo.md) |  |  [optional]
**olifEExtension** | [**List&lt;ApplicationnewTXLifeRequestOLifESourceInfoOlifEExtension&gt;**](ApplicationnewTXLifeRequestOLifESourceInfoOlifEExtension.md) |  |  [optional]



