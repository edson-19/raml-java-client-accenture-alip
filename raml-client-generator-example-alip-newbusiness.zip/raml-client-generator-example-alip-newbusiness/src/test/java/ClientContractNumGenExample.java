
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.mule.example.api.AlipnewbusinessClient;
import org.mule.example.exceptions.AlipnewbusinessException;
import org.mule.example.resource.contractNumGen.model.ContractNumGenPOSTBody;
import org.mule.example.resource.contractNumGen.model.ContractNumGenPOSTResponseBody;
import org.mule.example.responses.AlipnewbusinessResponse;

import com.fasterxml.jackson.databind.ObjectMapper;


public class ClientContractNumGenExample {
    public static void main(String[] args) {
        try {
        	input();
            final AlipnewbusinessResponse<ContractNumGenPOSTResponseBody> result = 
                	AlipnewbusinessClient.create("http://10.6.44.198:8080/relrt12wsgateway/api/ext-portal")
                	.contractNumGen.post(body());
            
            System.out.println ("TransRefGUID: " + result.getBody().getTXLife().getTXLifeResponse().getTransRefGUID());
            System.out.println ("TransExeDate: " + result.getBody().getTXLife().getTXLifeResponse().getTransExeDate());
            System.out.println ("TransExeTime: " + result.getBody().getTXLife().getTXLifeResponse().getTransExeTime());
            System.out.println ("ResultCode: " + result.getBody().getTXLife().getTXLifeResponse().getTransResult().getResultCode().get$());
            
        } catch ( AlipnewbusinessException e ) {
            System.err.println("ERROR: " + e.getStatusCode() + " " + e.getReason());
            System.err.println("ERROR: " + e.getResponse().toString());
            
        }
    }
    
    public static ContractNumGenPOSTBody body() {
    	ContractNumGenPOSTBody body;
    	String json = input(); 
        ObjectMapper mapper = new ObjectMapper();
        try {
        	body = mapper.readValue(json, ContractNumGenPOSTBody.class);
            
        	System.out.println("REQUEST: " + body.toString());
            System.out.println("UserLoginName: " + body.getTXLife().getUserAuthRequest().getUserLoginName());
            System.out.println("TransRefGUID: " + body.getTXLife().getTXLifeRequest().getTransRefGUID());
            System.out.println("PlanName: " + body.getTXLife().getTXLifeRequest().getOLifE().getHolding().getPolicy().getPlanName());
            
    		return body;
        } catch (IOException e) {
            e.printStackTrace();
        }
		return null;
    	
    }
    
    public static String input(){
      String input = null;
      StringBuilder builder = new StringBuilder();
      FileReader fr = null;
      BufferedReader br = null;
      try {
    	fr = new FileReader("src\\test\\java\\nb_contractNumGen_req.json");
    	br = new BufferedReader(fr);
    	String sCurrentLine;
		while ((sCurrentLine = br.readLine()) != null) {
			//System.out.println(sCurrentLine);
			builder.append(sCurrentLine);
		}
    	fr.close();
    	br.close();
      } catch (IOException e) {
    	  e.printStackTrace();
      } 
      //System.out.println("input: " + input);
      input = builder.toString();
      return input;
    }
    
}
