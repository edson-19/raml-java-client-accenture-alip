
# ApplicationsubmitTXLifeRequestOLifEPolicyPaymentMode

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tc** | [**TcEnum**](#TcEnum) |  |  [optional]
**value** | **String** |  |  [optional]


<a name="TcEnum"></a>
## Enum: TcEnum
Name | Value
---- | -----
_1 | &quot;1&quot;
_2 | &quot;2&quot;
_3 | &quot;3&quot;
_4 | &quot;4&quot;
_5 | &quot;5&quot;
_7 | &quot;7&quot;
_15 | &quot;15&quot;
_99 | &quot;99&quot;



