
# ApplicationsubmitTXLifeRequestOLifEPerson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**personKey** | [**ApplicationsubmitTXLifeRequestOLifEPersonPersonKey**](ApplicationsubmitTXLifeRequestOLifEPersonPersonKey.md) |  |  [optional]
**personSysKey** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEPersonPersonKey&gt;**](ApplicationsubmitTXLifeRequestOLifEPersonPersonKey.md) |  |  [optional]
**firstName** | **String** |  | 
**middleName** | **String** |  |  [optional]
**lastName** | **String** |  | 
**prefix** | [**PrefixEnum**](#PrefixEnum) |  |  [optional]
**suffix** | [**SuffixEnum**](#SuffixEnum) |  |  [optional]
**marStat** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**gender** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**birthDate** | **String** |  |  [optional]
**citizenship** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**estGrossAnnualOtherIncome** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**nonResidentAlienInd** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**occupation** | **String** |  |  [optional]
**olifEExtension** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEPolicyOLifEExtension&gt;**](ApplicationsubmitTXLifeRequestOLifEPolicyOLifEExtension.md) |  |  [optional]


<a name="PrefixEnum"></a>
## Enum: PrefixEnum
Name | Value
---- | -----
DR_ | &quot;Dr.&quot;
MR_ | &quot;Mr.&quot;
MRS_ | &quot;Mrs.&quot;
MS_ | &quot;Ms.&quot;
MISS | &quot;Miss&quot;


<a name="SuffixEnum"></a>
## Enum: SuffixEnum
Name | Value
---- | -----
ESQ | &quot;Esq&quot;
I | &quot;I&quot;
II | &quot;II&quot;
III | &quot;III&quot;
IV | &quot;IV&quot;
JR | &quot;Jr&quot;
MD | &quot;MD&quot;
PHD | &quot;PhD&quot;
RN | &quot;RN&quot;
SR | &quot;Sr&quot;



