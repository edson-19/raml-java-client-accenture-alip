# DefaultApi

All URIs are relative to *http://alipmule.eastus.cloudapp.azure.com/alip-newbusiness*

Method | HTTP request | Description
------------- | ------------- | -------------
[**agentsIdDashboardApplicationsStartDateEndDateGet**](DefaultApi.md#agentsIdDashboardApplicationsStartDateEndDateGet) | **GET** /agents/{id}/dashboard/applications/{startDate}/{endDate} | 
[**applicationExpressionsPost**](DefaultApi.md#applicationExpressionsPost) | **POST** /application/expressions | 
[**applicationIdPostSubmitDetailsGet**](DefaultApi.md#applicationIdPostSubmitDetailsGet) | **GET** /application/{id}/postSubmit/details | 
[**applicationIdPreSubmitDetailsGet**](DefaultApi.md#applicationIdPreSubmitDetailsGet) | **GET** /application/{id}/preSubmit/details | 
[**applicationNewPost**](DefaultApi.md#applicationNewPost) | **POST** /application/new | 
[**applicationSubmitPost**](DefaultApi.md#applicationSubmitPost) | **POST** /application/submit | 
[**contractNumGenPost**](DefaultApi.md#contractNumGenPost) | **POST** /contractNumGen | 
[**metadataTcdEappPost**](DefaultApi.md#metadataTcdEappPost) | **POST** /metadata/tcd/eapp | 


<a name="agentsIdDashboardApplicationsStartDateEndDateGet"></a>
# **agentsIdDashboardApplicationsStartDateEndDateGet**
> Map&lt;String, ERRORUNKNOWN&gt; agentsIdDashboardApplicationsStartDateEndDateGet(clientId, clientSecret, id, startDate, endDate)



New Business Search

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String clientId = "clientId_example"; // String | 
String clientSecret = "clientSecret_example"; // String | 
String id = "id_example"; // String | Agent Number
String startDate = "startDate_example"; // String | yyyymmdd
String endDate = "endDate_example"; // String | yyyymmdd
try {
    Map<String, ERRORUNKNOWN> result = apiInstance.agentsIdDashboardApplicationsStartDateEndDateGet(clientId, clientSecret, id, startDate, endDate);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#agentsIdDashboardApplicationsStartDateEndDateGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **clientId** | **String**|  |
 **clientSecret** | **String**|  |
 **id** | **String**| Agent Number |
 **startDate** | **String**| yyyymmdd |
 **endDate** | **String**| yyyymmdd |

### Return type

[**Map&lt;String, ERRORUNKNOWN&gt;**](ERRORUNKNOWN.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="applicationExpressionsPost"></a>
# **applicationExpressionsPost**
> ERRORUNKNOWN applicationExpressionsPost(clientId, clientSecret, generated)



CCL Expression used to call product rules

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String clientId = "clientId_example"; // String | 
String clientSecret = "clientSecret_example"; // String | 
ERRORUNKNOWN generated = new ERRORUNKNOWN(); // ERRORUNKNOWN | 
try {
    ERRORUNKNOWN result = apiInstance.applicationExpressionsPost(clientId, clientSecret, generated);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#applicationExpressionsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **clientId** | **String**|  |
 **clientSecret** | **String**|  |
 **generated** | [**ERRORUNKNOWN**](ERRORUNKNOWN.md)|  | [optional]

### Return type

[**ERRORUNKNOWN**](ERRORUNKNOWN.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="applicationIdPostSubmitDetailsGet"></a>
# **applicationIdPostSubmitDetailsGet**
> ERRORUNKNOWN applicationIdPostSubmitDetailsGet(clientId, clientSecret, id)



New Business PostSubmit Inquire

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String clientId = "clientId_example"; // String | 
String clientSecret = "clientSecret_example"; // String | 
String id = "id_example"; // String | Application ID
try {
    ERRORUNKNOWN result = apiInstance.applicationIdPostSubmitDetailsGet(clientId, clientSecret, id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#applicationIdPostSubmitDetailsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **clientId** | **String**|  |
 **clientSecret** | **String**|  |
 **id** | **String**| Application ID |

### Return type

[**ERRORUNKNOWN**](ERRORUNKNOWN.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="applicationIdPreSubmitDetailsGet"></a>
# **applicationIdPreSubmitDetailsGet**
> ERRORUNKNOWN applicationIdPreSubmitDetailsGet(clientId, clientSecret, id)



New Business PreSubmit Inquire

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String clientId = "clientId_example"; // String | 
String clientSecret = "clientSecret_example"; // String | 
String id = "id_example"; // String | Application ID
try {
    ERRORUNKNOWN result = apiInstance.applicationIdPreSubmitDetailsGet(clientId, clientSecret, id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#applicationIdPreSubmitDetailsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **clientId** | **String**|  |
 **clientSecret** | **String**|  |
 **id** | **String**| Application ID |

### Return type

[**ERRORUNKNOWN**](ERRORUNKNOWN.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="applicationNewPost"></a>
# **applicationNewPost**
> Map&lt;String, ERRORUNKNOWN&gt; applicationNewPost(clientId, clientSecret, generated)



New Business Application Save

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String clientId = "clientId_example"; // String | 
String clientSecret = "clientSecret_example"; // String | 
Generated1 generated = new Generated1(); // Generated1 | 
try {
    Map<String, ERRORUNKNOWN> result = apiInstance.applicationNewPost(clientId, clientSecret, generated);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#applicationNewPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **clientId** | **String**|  |
 **clientSecret** | **String**|  |
 **generated** | [**Generated1**](Generated1.md)|  | [optional]

### Return type

[**Map&lt;String, ERRORUNKNOWN&gt;**](ERRORUNKNOWN.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="applicationSubmitPost"></a>
# **applicationSubmitPost**
> Map&lt;String, ERRORUNKNOWN&gt; applicationSubmitPost(clientId, clientSecret, generated)



New Business Submit

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String clientId = "clientId_example"; // String | 
String clientSecret = "clientSecret_example"; // String | 
Generated generated = new Generated(); // Generated | 
try {
    Map<String, ERRORUNKNOWN> result = apiInstance.applicationSubmitPost(clientId, clientSecret, generated);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#applicationSubmitPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **clientId** | **String**|  |
 **clientSecret** | **String**|  |
 **generated** | [**Generated**](Generated.md)|  | [optional]

### Return type

[**Map&lt;String, ERRORUNKNOWN&gt;**](ERRORUNKNOWN.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="contractNumGenPost"></a>
# **contractNumGenPost**
> ERRORUNKNOWN contractNumGenPost(clientId, clientSecret, generated)



Contract Number Generation with Skeleton Application Save

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String clientId = "clientId_example"; // String | 
String clientSecret = "clientSecret_example"; // String | 
ERRORUNKNOWN generated = new ERRORUNKNOWN(); // ERRORUNKNOWN | 
try {
    ERRORUNKNOWN result = apiInstance.contractNumGenPost(clientId, clientSecret, generated);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#contractNumGenPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **clientId** | **String**|  |
 **clientSecret** | **String**|  |
 **generated** | [**ERRORUNKNOWN**](ERRORUNKNOWN.md)|  | [optional]

### Return type

[**ERRORUNKNOWN**](ERRORUNKNOWN.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="metadataTcdEappPost"></a>
# **metadataTcdEappPost**
> ERRORUNKNOWN metadataTcdEappPost(clientId, clientSecret, generated)



Code List Inquiry

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String clientId = "clientId_example"; // String | 
String clientSecret = "clientSecret_example"; // String | 
ERRORUNKNOWN generated = new ERRORUNKNOWN(); // ERRORUNKNOWN | 
try {
    ERRORUNKNOWN result = apiInstance.metadataTcdEappPost(clientId, clientSecret, generated);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#metadataTcdEappPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **clientId** | **String**|  |
 **clientSecret** | **String**|  |
 **generated** | [**ERRORUNKNOWN**](ERRORUNKNOWN.md)|  | [optional]

### Return type

[**ERRORUNKNOWN**](ERRORUNKNOWN.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

