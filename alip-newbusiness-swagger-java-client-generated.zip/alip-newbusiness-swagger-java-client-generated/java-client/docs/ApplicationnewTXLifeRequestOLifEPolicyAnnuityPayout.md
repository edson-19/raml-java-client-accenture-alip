
# ApplicationnewTXLifeRequestOLifEPolicyAnnuityPayout

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**annuityStartingDate** | **String** |  |  [optional]
**payoutMode** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]



