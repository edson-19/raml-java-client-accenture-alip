package com.accenture.alip.swagger.api;

import com.accenture.alip.swagger.invoker.ApiException;
import com.accenture.alip.swagger.invoker.ApiClient;
import com.accenture.alip.swagger.invoker.Configuration;
import com.accenture.alip.swagger.invoker.Pair;

import javax.ws.rs.core.GenericType;

import com.accenture.alip.swagger.model.Generated;
import com.accenture.alip.swagger.model.Generated1;
import com.accenture.alip.swagger.model.Generated2;
import com.accenture.alip.swagger.model.Generated3;
import com.accenture.alip.swagger.model.Generated4;
import com.accenture.alip.swagger.model.Generated5;
import com.accenture.alip.swagger.model.InlineResponse200;
import com.accenture.alip.swagger.model.InlineResponse2001;
import com.accenture.alip.swagger.model.InlineResponse2002;
import com.accenture.alip.swagger.model.InlineResponse2003;
import com.accenture.alip.swagger.model.InlineResponse2004;
import com.accenture.alip.swagger.model.InlineResponse2005;
import com.accenture.alip.swagger.model.InlineResponse2006;
import com.accenture.alip.swagger.model.InlineResponse2007;
import com.accenture.alip.swagger.model.InlineResponse2008;
import com.accenture.alip.swagger.model.InlineResponse2009;
import com.accenture.alip.swagger.model.InlineResponse400;
import com.accenture.alip.swagger.model.InlineResponse4001;
import com.accenture.alip.swagger.model.InlineResponse4002;
import com.accenture.alip.swagger.model.InlineResponse4003;
import com.accenture.alip.swagger.model.InlineResponse4004;
import com.accenture.alip.swagger.model.InlineResponse4005;
import com.accenture.alip.swagger.model.InlineResponse4006;
import com.accenture.alip.swagger.model.InlineResponse4007;
import com.accenture.alip.swagger.model.InlineResponse4008;
import com.accenture.alip.swagger.model.InlineResponse4009;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2019-05-21T09:58:34.534-04:00")
public class DefaultApi {
  private ApiClient apiClient;

  public DefaultApi() {
    this(Configuration.getDefaultApiClient());
  }

  public DefaultApi(ApiClient apiClient) {
    this.apiClient = apiClient;
  }

  public ApiClient getApiClient() {
    return apiClient;
  }

  public void setApiClient(ApiClient apiClient) {
    this.apiClient = apiClient;
  }

  /**
   * 
   * Withdrawal-Loan-Rebalance-Fund Transfer Request API
   * @param id Contract Number (required)
   * @param clientId Authorization required to access this API (Please check Request Access link on the top) (required)
   * @param clientSecret Authorization required to access this API (Please check Request Access link (required)
   * @param generated  (optional)
   * @return InlineResponse2003
   * @throws ApiException if fails to make API call
   */
  public InlineResponse2003 contractsIdTransactionsFundtransferPost(String id, String clientId, String clientSecret, Generated3 generated) throws ApiException {
    Object localVarPostBody = generated;
    
    // verify the required parameter 'id' is set
    if (id == null) {
      throw new ApiException(400, "Missing the required parameter 'id' when calling contractsIdTransactionsFundtransferPost");
    }
    
    // verify the required parameter 'clientId' is set
    if (clientId == null) {
      throw new ApiException(400, "Missing the required parameter 'clientId' when calling contractsIdTransactionsFundtransferPost");
    }
    
    // verify the required parameter 'clientSecret' is set
    if (clientSecret == null) {
      throw new ApiException(400, "Missing the required parameter 'clientSecret' when calling contractsIdTransactionsFundtransferPost");
    }
    
    // create path and map variables
    String localVarPath = "/contracts/{id}/transactions".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

    // query params
    List<Pair> localVarQueryParams = new ArrayList<Pair>();
    Map<String, String> localVarHeaderParams = new HashMap<String, String>();
    Map<String, Object> localVarFormParams = new HashMap<String, Object>();


    if (clientId != null)
      localVarHeaderParams.put("client_id", apiClient.parameterToString(clientId));
if (clientSecret != null)
      localVarHeaderParams.put("client_secret", apiClient.parameterToString(clientSecret));

    
    final String[] localVarAccepts = {
      
    };
    final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

    final String[] localVarContentTypes = {
      
    };
    final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

    String[] localVarAuthNames = new String[] {  };

    GenericType<InlineResponse2003> localVarReturnType = new GenericType<InlineResponse2003>() {};
    return apiClient.invokeAPI(localVarPath, "POST", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
      }
  /**
   * 
   * Withdrawal-Loan-Rebalance-Fund Transfer Request API
   * @param id Contract Number (required)
   * @param clientId Authorization required to access this API (Please check Request Access link on the top) (required)
   * @param clientSecret Authorization required to access this API (Please check Request Access link (required)
   * @param generated  (optional)
   * @return InlineResponse2001
   * @throws ApiException if fails to make API call
   */
  public InlineResponse2001 contractsIdTransactionsLoanPost(String id, String clientId, String clientSecret, Generated1 generated) throws ApiException {
    Object localVarPostBody = generated;
    
    // verify the required parameter 'id' is set
    if (id == null) {
      throw new ApiException(400, "Missing the required parameter 'id' when calling contractsIdTransactionsLoanPost");
    }
    
    // verify the required parameter 'clientId' is set
    if (clientId == null) {
      throw new ApiException(400, "Missing the required parameter 'clientId' when calling contractsIdTransactionsLoanPost");
    }
    
    // verify the required parameter 'clientSecret' is set
    if (clientSecret == null) {
      throw new ApiException(400, "Missing the required parameter 'clientSecret' when calling contractsIdTransactionsLoanPost");
    }
    
    // create path and map variables
    String localVarPath = "/contracts/{id}/transactions".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

    // query params
    List<Pair> localVarQueryParams = new ArrayList<Pair>();
    Map<String, String> localVarHeaderParams = new HashMap<String, String>();
    Map<String, Object> localVarFormParams = new HashMap<String, Object>();


    if (clientId != null)
      localVarHeaderParams.put("client_id", apiClient.parameterToString(clientId));
if (clientSecret != null)
      localVarHeaderParams.put("client_secret", apiClient.parameterToString(clientSecret));

    
    final String[] localVarAccepts = {
      
    };
    final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

    final String[] localVarContentTypes = {
      
    };
    final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

    String[] localVarAuthNames = new String[] {  };

    GenericType<InlineResponse2001> localVarReturnType = new GenericType<InlineResponse2001>() {};
    return apiClient.invokeAPI(localVarPath, "POST", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
      }
  /**
   * 
   * Withdrawal-Loan-Rebalance-Fund Transfer Request API
   * @param id Contract Number (required)
   * @param clientId Authorization required to access this API (Please check Request Access link on the top) (required)
   * @param clientSecret Authorization required to access this API (Please check Request Access link (required)
   * @param generated  (optional)
   * @return InlineResponse2002
   * @throws ApiException if fails to make API call
   */
  public InlineResponse2002 contractsIdTransactionsRebalancePost(String id, String clientId, String clientSecret, Generated2 generated) throws ApiException {
    Object localVarPostBody = generated;
    
    // verify the required parameter 'id' is set
    if (id == null) {
      throw new ApiException(400, "Missing the required parameter 'id' when calling contractsIdTransactionsRebalancePost");
    }
    
    // verify the required parameter 'clientId' is set
    if (clientId == null) {
      throw new ApiException(400, "Missing the required parameter 'clientId' when calling contractsIdTransactionsRebalancePost");
    }
    
    // verify the required parameter 'clientSecret' is set
    if (clientSecret == null) {
      throw new ApiException(400, "Missing the required parameter 'clientSecret' when calling contractsIdTransactionsRebalancePost");
    }
    
    // create path and map variables
    String localVarPath = "/contracts/{id}/transactions".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

    // query params
    List<Pair> localVarQueryParams = new ArrayList<Pair>();
    Map<String, String> localVarHeaderParams = new HashMap<String, String>();
    Map<String, Object> localVarFormParams = new HashMap<String, Object>();


    if (clientId != null)
      localVarHeaderParams.put("client_id", apiClient.parameterToString(clientId));
if (clientSecret != null)
      localVarHeaderParams.put("client_secret", apiClient.parameterToString(clientSecret));

    
    final String[] localVarAccepts = {
      
    };
    final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

    final String[] localVarContentTypes = {
      
    };
    final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

    String[] localVarAuthNames = new String[] {  };

    GenericType<InlineResponse2002> localVarReturnType = new GenericType<InlineResponse2002>() {};
    return apiClient.invokeAPI(localVarPath, "POST", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
      }
  /**
   * 
   * Withdrawal-Loan-Rebalance-Fund Transfer Request API
   * @param id Contract Number (required)
   * @param clientId Authorization required to access this API (Please check Request Access link on the top) (required)
   * @param clientSecret Authorization required to access this API (Please check Request Access link (required)
   * @param generated  (optional)
   * @return InlineResponse200
   * @throws ApiException if fails to make API call
   */
  public InlineResponse200 contractsIdTransactionsWithdrawalPost(String id, String clientId, String clientSecret, Generated generated) throws ApiException {
    Object localVarPostBody = generated;
    
    // verify the required parameter 'id' is set
    if (id == null) {
      throw new ApiException(400, "Missing the required parameter 'id' when calling contractsIdTransactionsWithdrawalPost");
    }
    
    // verify the required parameter 'clientId' is set
    if (clientId == null) {
      throw new ApiException(400, "Missing the required parameter 'clientId' when calling contractsIdTransactionsWithdrawalPost");
    }
    
    // verify the required parameter 'clientSecret' is set
    if (clientSecret == null) {
      throw new ApiException(400, "Missing the required parameter 'clientSecret' when calling contractsIdTransactionsWithdrawalPost");
    }
    
    // create path and map variables
    String localVarPath = "/contracts/{id}/transactions".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

    // query params
    List<Pair> localVarQueryParams = new ArrayList<Pair>();
    Map<String, String> localVarHeaderParams = new HashMap<String, String>();
    Map<String, Object> localVarFormParams = new HashMap<String, Object>();


    if (clientId != null)
      localVarHeaderParams.put("client_id", apiClient.parameterToString(clientId));
if (clientSecret != null)
      localVarHeaderParams.put("client_secret", apiClient.parameterToString(clientSecret));

    
    final String[] localVarAccepts = {
      
    };
    final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

    final String[] localVarContentTypes = {
      
    };
    final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

    String[] localVarAuthNames = new String[] {  };

    GenericType<InlineResponse200> localVarReturnType = new GenericType<InlineResponse200>() {};
    return apiClient.invokeAPI(localVarPath, "POST", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
      }
  /**
   * 
   * 
   * @param clientId Authorization required to access this API (Please check Request Access link on the top) (required)
   * @param clientSecret Authorization required to access this API (Please check Request Access link (required)
   * @param generated  (optional)
   * @return InlineResponse2009
   * @throws ApiException if fails to make API call
   */
  public InlineResponse2009 paymentRejectTransactionPost(String clientId, String clientSecret, Generated5 generated) throws ApiException {
    Object localVarPostBody = generated;
    
    // verify the required parameter 'clientId' is set
    if (clientId == null) {
      throw new ApiException(400, "Missing the required parameter 'clientId' when calling paymentRejectTransactionPost");
    }
    
    // verify the required parameter 'clientSecret' is set
    if (clientSecret == null) {
      throw new ApiException(400, "Missing the required parameter 'clientSecret' when calling paymentRejectTransactionPost");
    }
    
    // create path and map variables
    String localVarPath = "/PaymentReject/Transaction".replaceAll("\\{format\\}","json");

    // query params
    List<Pair> localVarQueryParams = new ArrayList<Pair>();
    Map<String, String> localVarHeaderParams = new HashMap<String, String>();
    Map<String, Object> localVarFormParams = new HashMap<String, Object>();


    if (clientId != null)
      localVarHeaderParams.put("client_id", apiClient.parameterToString(clientId));
if (clientSecret != null)
      localVarHeaderParams.put("client_secret", apiClient.parameterToString(clientSecret));

    
    final String[] localVarAccepts = {
      
    };
    final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

    final String[] localVarContentTypes = {
      
    };
    final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

    String[] localVarAuthNames = new String[] {  };

    GenericType<InlineResponse2009> localVarReturnType = new GenericType<InlineResponse2009>() {};
    return apiClient.invokeAPI(localVarPath, "POST", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
      }
  /**
   * 
   * 
   * @param clientId Authorization required to access this API (Please check Request Access link on the top) (required)
   * @param clientSecret Authorization required to access this API (Please check Request Access link (required)
   * @param generated  (optional)
   * @return InlineResponse2008
   * @throws ApiException if fails to make API call
   */
  public InlineResponse2008 suspenseContractPost(String clientId, String clientSecret, Generated4 generated) throws ApiException {
    Object localVarPostBody = generated;
    
    // verify the required parameter 'clientId' is set
    if (clientId == null) {
      throw new ApiException(400, "Missing the required parameter 'clientId' when calling suspenseContractPost");
    }
    
    // verify the required parameter 'clientSecret' is set
    if (clientSecret == null) {
      throw new ApiException(400, "Missing the required parameter 'clientSecret' when calling suspenseContractPost");
    }
    
    // create path and map variables
    String localVarPath = "/Suspense/contract".replaceAll("\\{format\\}","json");

    // query params
    List<Pair> localVarQueryParams = new ArrayList<Pair>();
    Map<String, String> localVarHeaderParams = new HashMap<String, String>();
    Map<String, Object> localVarFormParams = new HashMap<String, Object>();


    if (clientId != null)
      localVarHeaderParams.put("client_id", apiClient.parameterToString(clientId));
if (clientSecret != null)
      localVarHeaderParams.put("client_secret", apiClient.parameterToString(clientSecret));

    
    final String[] localVarAccepts = {
      
    };
    final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

    final String[] localVarContentTypes = {
      
    };
    final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

    String[] localVarAuthNames = new String[] {  };

    GenericType<InlineResponse2008> localVarReturnType = new GenericType<InlineResponse2008>() {};
    return apiClient.invokeAPI(localVarPath, "POST", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
      }
  /**
   * 
   * 
   * @param id Contract Number (required)
   * @param clientId Authorization required to access this API (Please check Request Access link on the top) (required)
   * @param clientSecret Authorization required to access this API (Please check Request Access link (required)
   * @return InlineResponse2004
   * @throws ApiException if fails to make API call
   */
  public InlineResponse2004 transactionsContractIdAvailableGet(String id, String clientId, String clientSecret) throws ApiException {
    Object localVarPostBody = null;
    
    // verify the required parameter 'id' is set
    if (id == null) {
      throw new ApiException(400, "Missing the required parameter 'id' when calling transactionsContractIdAvailableGet");
    }
    
    // verify the required parameter 'clientId' is set
    if (clientId == null) {
      throw new ApiException(400, "Missing the required parameter 'clientId' when calling transactionsContractIdAvailableGet");
    }
    
    // verify the required parameter 'clientSecret' is set
    if (clientSecret == null) {
      throw new ApiException(400, "Missing the required parameter 'clientSecret' when calling transactionsContractIdAvailableGet");
    }
    
    // create path and map variables
    String localVarPath = "/transactions/contract/{id}/available".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

    // query params
    List<Pair> localVarQueryParams = new ArrayList<Pair>();
    Map<String, String> localVarHeaderParams = new HashMap<String, String>();
    Map<String, Object> localVarFormParams = new HashMap<String, Object>();


    if (clientId != null)
      localVarHeaderParams.put("client_id", apiClient.parameterToString(clientId));
if (clientSecret != null)
      localVarHeaderParams.put("client_secret", apiClient.parameterToString(clientSecret));

    
    final String[] localVarAccepts = {
      
    };
    final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

    final String[] localVarContentTypes = {
      
    };
    final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

    String[] localVarAuthNames = new String[] {  };

    GenericType<InlineResponse2004> localVarReturnType = new GenericType<InlineResponse2004>() {};
    return apiClient.invokeAPI(localVarPath, "GET", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
      }
  /**
   * 
   * 
   * @param id Contract Number (required)
   * @param clientId Authorization required to access this API (Please check Request Access link on the top) (required)
   * @param clientSecret Authorization required to access this API (Please check Request Access link (required)
   * @return InlineResponse2007
   * @throws ApiException if fails to make API call
   */
  public InlineResponse2007 transactionsContractIdHistoryGet(String id, String clientId, String clientSecret) throws ApiException {
    Object localVarPostBody = null;
    
    // verify the required parameter 'id' is set
    if (id == null) {
      throw new ApiException(400, "Missing the required parameter 'id' when calling transactionsContractIdHistoryGet");
    }
    
    // verify the required parameter 'clientId' is set
    if (clientId == null) {
      throw new ApiException(400, "Missing the required parameter 'clientId' when calling transactionsContractIdHistoryGet");
    }
    
    // verify the required parameter 'clientSecret' is set
    if (clientSecret == null) {
      throw new ApiException(400, "Missing the required parameter 'clientSecret' when calling transactionsContractIdHistoryGet");
    }
    
    // create path and map variables
    String localVarPath = "/transactions/contract/{id}/history".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()));

    // query params
    List<Pair> localVarQueryParams = new ArrayList<Pair>();
    Map<String, String> localVarHeaderParams = new HashMap<String, String>();
    Map<String, Object> localVarFormParams = new HashMap<String, Object>();


    if (clientId != null)
      localVarHeaderParams.put("client_id", apiClient.parameterToString(clientId));
if (clientSecret != null)
      localVarHeaderParams.put("client_secret", apiClient.parameterToString(clientSecret));

    
    final String[] localVarAccepts = {
      
    };
    final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

    final String[] localVarContentTypes = {
      
    };
    final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

    String[] localVarAuthNames = new String[] {  };

    GenericType<InlineResponse2007> localVarReturnType = new GenericType<InlineResponse2007>() {};
    return apiClient.invokeAPI(localVarPath, "GET", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
      }
  /**
   * 
   * 
   * @param id Contract Number (required)
   * @param startDate yyyymmdd (required)
   * @param endDate yyyymmdd (required)
   * @param clientId Authorization required to access this API (Please check Request Access link on the top) (required)
   * @param clientSecret Authorization required to access this API (Please check Request Access link (required)
   * @return InlineResponse2005
   * @throws ApiException if fails to make API call
   */
  public InlineResponse2005 transactionsContractIdHistoryStartDateEndDateGet(String id, String startDate, String endDate, String clientId, String clientSecret) throws ApiException {
    Object localVarPostBody = null;
    
    // verify the required parameter 'id' is set
    if (id == null) {
      throw new ApiException(400, "Missing the required parameter 'id' when calling transactionsContractIdHistoryStartDateEndDateGet");
    }
    
    // verify the required parameter 'startDate' is set
    if (startDate == null) {
      throw new ApiException(400, "Missing the required parameter 'startDate' when calling transactionsContractIdHistoryStartDateEndDateGet");
    }
    
    // verify the required parameter 'endDate' is set
    if (endDate == null) {
      throw new ApiException(400, "Missing the required parameter 'endDate' when calling transactionsContractIdHistoryStartDateEndDateGet");
    }
    
    // verify the required parameter 'clientId' is set
    if (clientId == null) {
      throw new ApiException(400, "Missing the required parameter 'clientId' when calling transactionsContractIdHistoryStartDateEndDateGet");
    }
    
    // verify the required parameter 'clientSecret' is set
    if (clientSecret == null) {
      throw new ApiException(400, "Missing the required parameter 'clientSecret' when calling transactionsContractIdHistoryStartDateEndDateGet");
    }
    
    // create path and map variables
    String localVarPath = "/transactions/contract/{id}/history/{startDate}/{endDate}".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()))
      .replaceAll("\\{" + "startDate" + "\\}", apiClient.escapeString(startDate.toString()))
      .replaceAll("\\{" + "endDate" + "\\}", apiClient.escapeString(endDate.toString()));

    // query params
    List<Pair> localVarQueryParams = new ArrayList<Pair>();
    Map<String, String> localVarHeaderParams = new HashMap<String, String>();
    Map<String, Object> localVarFormParams = new HashMap<String, Object>();


    if (clientId != null)
      localVarHeaderParams.put("client_id", apiClient.parameterToString(clientId));
if (clientSecret != null)
      localVarHeaderParams.put("client_secret", apiClient.parameterToString(clientSecret));

    
    final String[] localVarAccepts = {
      
    };
    final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

    final String[] localVarContentTypes = {
      
    };
    final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

    String[] localVarAuthNames = new String[] {  };

    GenericType<InlineResponse2005> localVarReturnType = new GenericType<InlineResponse2005>() {};
    return apiClient.invokeAPI(localVarPath, "GET", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
      }
  /**
   * 
   * 
   * @param id Contract Number (required)
   * @param startDate yyyymmdd (required)
   * @param clientId Authorization required to access this API (Please check Request Access link on the top) (required)
   * @param clientSecret Authorization required to access this API (Please check Request Access link (required)
   * @return InlineResponse2006
   * @throws ApiException if fails to make API call
   */
  public InlineResponse2006 transactionsContractIdHistoryStartDateGet(String id, String startDate, String clientId, String clientSecret) throws ApiException {
    Object localVarPostBody = null;
    
    // verify the required parameter 'id' is set
    if (id == null) {
      throw new ApiException(400, "Missing the required parameter 'id' when calling transactionsContractIdHistoryStartDateGet");
    }
    
    // verify the required parameter 'startDate' is set
    if (startDate == null) {
      throw new ApiException(400, "Missing the required parameter 'startDate' when calling transactionsContractIdHistoryStartDateGet");
    }
    
    // verify the required parameter 'clientId' is set
    if (clientId == null) {
      throw new ApiException(400, "Missing the required parameter 'clientId' when calling transactionsContractIdHistoryStartDateGet");
    }
    
    // verify the required parameter 'clientSecret' is set
    if (clientSecret == null) {
      throw new ApiException(400, "Missing the required parameter 'clientSecret' when calling transactionsContractIdHistoryStartDateGet");
    }
    
    // create path and map variables
    String localVarPath = "/transactions/contract/{id}/history/{startDate}".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "id" + "\\}", apiClient.escapeString(id.toString()))
      .replaceAll("\\{" + "startDate" + "\\}", apiClient.escapeString(startDate.toString()));

    // query params
    List<Pair> localVarQueryParams = new ArrayList<Pair>();
    Map<String, String> localVarHeaderParams = new HashMap<String, String>();
    Map<String, Object> localVarFormParams = new HashMap<String, Object>();


    if (clientId != null)
      localVarHeaderParams.put("client_id", apiClient.parameterToString(clientId));
if (clientSecret != null)
      localVarHeaderParams.put("client_secret", apiClient.parameterToString(clientSecret));

    
    final String[] localVarAccepts = {
      
    };
    final String localVarAccept = apiClient.selectHeaderAccept(localVarAccepts);

    final String[] localVarContentTypes = {
      
    };
    final String localVarContentType = apiClient.selectHeaderContentType(localVarContentTypes);

    String[] localVarAuthNames = new String[] {  };

    GenericType<InlineResponse2006> localVarReturnType = new GenericType<InlineResponse2006>() {};
    return apiClient.invokeAPI(localVarPath, "GET", localVarQueryParams, localVarPostBody, localVarHeaderParams, localVarFormParams, localVarAccept, localVarContentType, localVarAuthNames, localVarReturnType);
      }
}
