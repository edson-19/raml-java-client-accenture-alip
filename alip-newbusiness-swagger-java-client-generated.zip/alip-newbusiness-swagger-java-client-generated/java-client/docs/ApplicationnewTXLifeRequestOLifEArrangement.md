
# ApplicationnewTXLifeRequestOLifEArrangement

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**arrMode** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  | 
**arrType** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  | 
**arrSubType** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**startDate** | **String** |  | 
**endDate** | **String** |  | 
**modalAmt** | [**BigDecimal**](BigDecimal.md) |  | 
**numOfModalOccurrences** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**dayOfMonth** | [**ApplicationsubmitTXLifeRequestOLifEDayOfMonth**](ApplicationsubmitTXLifeRequestOLifEDayOfMonth.md) |  |  [optional]
**businessDayOfMonth** | [**ApplicationsubmitTXLifeRequestOLifEBusinessDayOfMonth**](ApplicationsubmitTXLifeRequestOLifEBusinessDayOfMonth.md) |  |  [optional]
**arrSource** | [**ApplicationsubmitTXLifeRequestOLifEArrSource**](ApplicationsubmitTXLifeRequestOLifEArrSource.md) |  |  [optional]
**arrDestination** | [**ApplicationsubmitTXLifeRequestOLifEArrSource**](ApplicationsubmitTXLifeRequestOLifEArrSource.md) |  |  [optional]
**olifEExtension** | [**List&lt;ApplicationnewTXLifeRequestOLifESourceInfoOlifEExtension&gt;**](ApplicationnewTXLifeRequestOLifESourceInfoOlifEExtension.md) |  |  [optional]



