
# ApplicationsubmitTXLifeRequestOLifEPolicyAnnuityProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**featureProduct** | [**ApplicationsubmitTXLifeRequestOLifEPolicyAnnuityProductFeatureProduct**](ApplicationsubmitTXLifeRequestOLifEPolicyAnnuityProductFeatureProduct.md) |  |  [optional]



