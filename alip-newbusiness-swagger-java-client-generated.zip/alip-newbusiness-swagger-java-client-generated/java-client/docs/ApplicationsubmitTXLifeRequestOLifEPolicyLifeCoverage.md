
# ApplicationsubmitTXLifeRequestOLifEPolicyLifeCoverage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**deathBenefitOptType** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**lifeParticipant** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEPolicyLifeLifeParticipant&gt;**](ApplicationsubmitTXLifeRequestOLifEPolicyLifeLifeParticipant.md) |  |  [optional]
**covOption** | **String** |  |  [optional]



