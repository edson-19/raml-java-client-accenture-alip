
# ApplicationsubmitTXLifeRequestOLifEProducer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**niPRNumber** | **String** |  |  [optional]



