
# ApplicationsubmitTXLifeRequestOLifEPolicyAnnuityProductFeatureProductFeatureOptProduct

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productCode** | **String** |  | 
**name** | **String** |  |  [optional]



