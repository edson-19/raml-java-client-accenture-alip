
# Generated1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **String** |  |  [optional]
**userAuthRequest** | [**ApplicationsubmitUserAuthRequest**](ApplicationsubmitUserAuthRequest.md) |  |  [optional]
**txLifeRequest** | [**ApplicationnewTXLifeRequest**](ApplicationnewTXLifeRequest.md) |  |  [optional]



