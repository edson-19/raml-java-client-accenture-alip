
# ApplicationsubmitTXLifeRequestOLifEInvestmentSubAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**productCode** | **String** |  |  [optional]
**productFullName** | **String** |  |  [optional]
**investType** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**allocPercent** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**financialActivity** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEInvestmentFinancialActivity&gt;**](ApplicationsubmitTXLifeRequestOLifEInvestmentFinancialActivity.md) |  |  [optional]



