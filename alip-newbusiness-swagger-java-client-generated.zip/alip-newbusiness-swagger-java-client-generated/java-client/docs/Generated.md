
# Generated

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **String** |  |  [optional]
**userAuthRequest** | [**ApplicationsubmitUserAuthRequest**](ApplicationsubmitUserAuthRequest.md) |  |  [optional]
**txLifeRequest** | [**ApplicationsubmitTXLifeRequest**](ApplicationsubmitTXLifeRequest.md) |  |  [optional]



