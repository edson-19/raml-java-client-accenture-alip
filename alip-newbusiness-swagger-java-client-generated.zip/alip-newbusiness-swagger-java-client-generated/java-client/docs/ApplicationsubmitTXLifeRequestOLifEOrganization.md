
# ApplicationsubmitTXLifeRequestOLifEOrganization

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**organizationKey** | [**ApplicationsubmitTXLifeRequestOLifEPersonPersonKey**](ApplicationsubmitTXLifeRequestOLifEPersonPersonKey.md) |  |  [optional]
**organizationSysKey** | [**List&lt;ApplicationsubmitTXLifeRequestOLifEPersonPersonKey&gt;**](ApplicationsubmitTXLifeRequestOLifEPersonPersonKey.md) |  |  [optional]
**orgForm** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**trustType** | [**ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode**](ApplicationsubmitTXLifeRequestOLifEHoldingTypeCode.md) |  |  [optional]
**estabDate** | **String** |  |  [optional]
**id** | **String** |  |  [optional]
**dataRep** | **String** |  |  [optional]



