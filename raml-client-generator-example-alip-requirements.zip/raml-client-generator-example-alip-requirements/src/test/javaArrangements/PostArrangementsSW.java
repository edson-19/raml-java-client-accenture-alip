
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import org.glassfish.jersey.client.ClientProperties;

import org.mule.example.api.AliparrangementsClient;
import org.mule.example.exceptions.AliparrangementsException;
import org.mule.example.resource.contracts.id.arrangements.model.ArrangementsGETResponseBody;
import org.mule.example.resource.contracts.id.arrangements.model.ArrangementsPOSTBody;
import org.mule.example.responses.AliparrangementsResponse;

import com.fasterxml.jackson.databind.ObjectMapper;


public class PostArrangementsSW {
	@SuppressWarnings("static-access")
    public static void main(String[] args) {
        try {
        	/*
        	final AliparrangementsResponse<Object> result = new AliparrangementsClient() {
                @Override
                protected Client getClient() {
                    final Client client = ClientBuilder.newClient();
                    client.property(ClientProperties.CONNECT_TIMEOUT, 600000);
                    client.property(ClientProperties.READ_TIMEOUT, 600000);
                    return client;
                }
            }.create("http://10.6.44.198:8080/relrt12wsgateway/api/ext-portal")
        			.contracts.id("83914").arrangements.post(body());
        	*/
        	
            final AliparrangementsResponse<ArrangementsGETResponseBody> result = 
            		//AliparrangementsClient.create("http://10.6.44.198:8080/relrt12wsgateway/api/ext-portal")
            		AliparrangementsClient.create()
            			.contracts.id("83914").arrangements.post(body());
            
            System.out.println ("RESPONSE: " + result.getBody().toString());
            System.out.println ("TransRefGUID: " + result.getBody().getTXLife().getTXLifeResponse().getTransRefGUID());
            System.out.println ("TransExeDate: " + result.getBody().getTXLife().getTXLifeResponse().getTransExeDate());
            System.out.println ("TransExeTime: " + result.getBody().getTXLife().getTXLifeResponse().getTransExeTime());
            System.out.println ("ResultCode: " + result.getBody().getTXLife().getTXLifeResponse().getTransResult().getResultCode().get$());
            System.out.println ("Response: " + result.getResponse().getStatusInfo());
            
        } catch ( AliparrangementsException e ) {
            System.err.println("ERROR: " + e.getStatusCode() + " " + e.getReason());
            System.err.println("ERROR: " + e.getResponse().toString());
            e.printStackTrace();
            
        }
    }
    
    public static ArrangementsPOSTBody body() {
    	ArrangementsPOSTBody body;
    	String json = input(); 
        ObjectMapper mapper = new ObjectMapper();
        try {
        	body = mapper.readValue(json, ArrangementsPOSTBody.class);
            
        	System.out.println("REQUEST: " + body.toString());
            //System.out.println("UserLoginName: " + body.getTXLife().getUserAuthRequest().getUserLoginName());
            System.out.println("TransRefGUID: " + body.getTXLife().getTXLifeRequest().getTransRefGUID());
            System.out.println("PolNumber: " + body.getTXLife().getTXLifeRequest().getOLifE().getHolding().getPolicy().getPolNumber());
            
    		return body;
        } catch (IOException e) {
            e.printStackTrace();
        }
		return null;
    	
    }
    
    public static String input(){
      String input = null;
      StringBuilder builder = new StringBuilder();
      FileReader fr = null;
      BufferedReader br = null;
      try {
    	fr = new FileReader("src\\test\\java\\arrangement_sw_req.json");
    	br = new BufferedReader(fr);
    	String sCurrentLine;
		while ((sCurrentLine = br.readLine()) != null) {
			//System.out.println(sCurrentLine);
			builder.append(sCurrentLine);
		}
    	fr.close();
    	br.close();
      } catch (IOException e) {
    	  e.printStackTrace();
      } 
      //System.out.println("input: " + input);
      input = builder.toString();
      return input;
    }
    
}
